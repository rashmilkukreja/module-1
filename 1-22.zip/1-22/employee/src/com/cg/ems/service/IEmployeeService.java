package com.cg.ems.service;

import java.util.ArrayList;

import com.cg.ems.exception.EmployeeException;
import com.cg.ems.dto.Employee;

public interface IEmployeeService 
{
                public int addEmployee(Employee emp) throws EmployeeException;
                public void updateEmployee(Employee empl);
                public ArrayList<Employee> viewAll() throws EmployeeException; // throws EmployeeException;
                public void removeEmployee(int empId);
              public Employee searchEmployee(int empid) throws EmployeeException;

}

