package com.cg.ems.ui;


import java.util.List;
import java.util.Scanner;

import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmployeeServiceImpl;
import com.cg.ems.service.IEmployeeService;
import com.cg.ems.dto.Employee;


public class EmployeeManagement 
{
                public static void main(String[] args) {
                
                                int choice= 0;
                                IEmployeeService empService=new EmployeeServiceImpl(); //Runtime polymorphism
                                
                                
                                do{
                                                printDetails();
                                                Scanner scr=new Scanner(System.in);
                                                System.out.println("Enter choice");
                                                choice= scr.nextInt();
                                                
                                                switch(choice)
                                                {
                                                case 1://add
                                                                int msg=0;
                                                                System.out.println("Enter employee ID");
                                                                int empId=scr.nextInt();
                                                                System.out.println("Enter Employee Name");
                                                                String empName=scr.next();
                                                                System.out.println("Enter Salary");
                                                                double sal=scr.nextDouble();
                                                                System.out.println("Enter designation");
                                                                String des=scr.next();
                                                                
                                                                Employee emp=new Employee();
                                                                emp.setEmpId(empId);
                                                                emp.setEmpName(empName);
                                                                emp.setSalary(sal);
                                                                emp.setDes(des);
                                                                try {
                                                                                msg = empService.addEmployee(emp);
                                                                                
                                                                                                
                                                                                 } catch (EmployeeException e) {
                                                                                
                                                                                e.printStackTrace();
                                                                                System.out.println(e.getMessage());
                                                                }
                                                                if(msg==1)
                                                                {
                                                                                System.out.println("Data inserted...");
                                                                }
                                                
                                                                break; 
                                                
                                                
                                                case 2://update
                                                                
                                                                
                                                                break;
                                                case 3://remove
                                                                break;
                                                case 4://view
                                                                
                                                                List<Employee> myemp = null;
                                                                try {
                                                                                myemp = null;
                                                                                myemp = empService.viewAll();
                                                                } catch (EmployeeException e) {
                                                                                
                                                                                e.printStackTrace();
                                                                                System.out.println(e.getMessage());
                                                                }
                                                                for (Employee employee : myemp) {
                                                                                System.out.println("id is "+ employee.getEmpId());
                                                                                System.out.println("Name is "+employee.getEmpName());
                                                                                System.out.println("Salary is " +employee.getSalary());
                                                                                System.out.println("Designation is " +employee.getDes());
                                                                                
                                                                }
                                                                break; 
                                                case 5:   //search
                                                                System.out.println("Enter employee id");
                                                                int id=scr.nextInt();
                                                                Employee mySearchEmp = null;
													try {
														myemp=empService.viewAll();
													} catch (EmployeeException e) {
														// TODO Auto-generated catch block
														e.printStackTrace();
													}
                                                                
                                                                if(mySearchEmp==null)
                                                                {
                                                                System.out.println("Enter valid id");
                                                                }
                                                                else
                                                                {
                                                                                System.out.println("Id is " +mySearchEmp.getEmpId());
                                                                                System.out.println("Name is " +mySearchEmp.getEmpName());
                                                                                System.out.println("Salary is " +mySearchEmp.getSalary());
                                                                                System.out.println("Designation is " +mySearchEmp.getDes());
                                                                                
                                                                }
                                                                
                                                                
                                                                break;
                                                
                                                
                                                case 6:System.exit(0);
                                                                
                                                }
                                }
                                while(choice!=6); 
                                
                                
                                
                                
                }
                public static void printDetails()
                {
                                System.out.println("1. Add Employee");
                                System.out.println("2. Update Employees");
                                System.out.println("3. Remove Employees");
                                System.out.println("4. View all Employees");
                                System.out.println("5. Search employee");
                                System.out.println("6. Exit");
                }

}

