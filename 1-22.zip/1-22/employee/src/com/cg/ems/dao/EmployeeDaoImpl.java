package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DbUtil;
import com.cg.ems.dto.Employee;

public class EmployeeDaoImpl implements IEmployeeDAO 
{

                Connection conn=null;
                PreparedStatement pstm=null;
                
                @Override
                public int addEmployee(Employee empl) throws EmployeeException 
                {
                                int status=0;
                                conn=DbUtil.getConnection();
                                String query="Insert into Employeedb values(?,?,?,?)";
                                try {
                                                pstm=conn.prepareStatement(query);
                                                pstm.setInt(1,empl.getEmpId());
                                                pstm.setString(2,empl.getEmpName());
                                                pstm.setDouble(3, empl.getSalary());
                                                pstm.setString(4, empl.getDes());
                                                status = pstm.executeUpdate();
                                                
                                } catch (SQLException e) {
                                                
                                                e.printStackTrace();
                                }
                                finally
                                {
                                                try {
                                                                pstm.close();
                                                                conn.close();
                                                } catch (SQLException e) {
                                                                e.printStackTrace();
                                                                throw new EmployeeException("Problem in insert..");
                                                }
                                                
                                }
                                
                                
                return status;
                }
                

                @Override
                public void updateEmployee(Employee empl) {
                                // TODO Auto-generated method stub
                                
                }

                @Override
                public ArrayList<Employee> viewAll() throws EmployeeException {
                                ArrayList<Employee> myList = new ArrayList<Employee>();
                                conn=DbUtil.getConnection();
                                String querytwo="Select EMPID,EMPNAME,SALARY,DES from employeedb";
                                try {
                                                pstm=conn.prepareStatement(querytwo);
                                                ResultSet res=pstm.executeQuery();
                                                System.out.println("View all working...");
                                                while(res.next())
                                                {
                                                                Employee em=new Employee();
                                                                em.setEmpId(res.getInt("EMPID"));
                                                                em.setEmpName(res.getString("EMPNAME"));
                                                                em.setSalary(res.getDouble("SALARY"));
                                                                em.setDes(res.getString("DES"));
                                                
                                                                
                                                                myList.add(em);
                                                }
                                                
                                                
                                } catch (SQLException e) {
                                                throw new EmployeeException("Problem in view..");
                                               //e.printStackTrace();
                                }
                                
                                finally
                                {
                                                try {
                                                                pstm.close();
                                                                conn.close();
                                                } catch (SQLException e) {
                                                                e.printStackTrace();
                                                }
                                                
                                }
                                return myList;
                }

                @Override
                public void removeEmployee(int empId) {
                                // TODO Auto-generated method stub
                                
                }


				@Override
				public ArrayList<Employee> searchEmployee()
						throws EmployeeException {
					// TODO Auto-generated method stub
					return null;
				}


				


              // @Override
              public Employee searchEmployee(int empid) throws EmployeeException
              {
                              Employee esearch=null;
                             try {
                                           conn=DbUtil.getConnection();
                                            String querythree="Select emp_name,emp_sal,emp_des from employeedb where emp_id=?";
                                              pstm=conn.prepareStatement(querythree);
                                              pstm.setInt(1,empid);
                                                                         
                                                                           
                                                                             
                             } 
                              catch (EmployeeException | SQLException e) 
                             {          throw new EmployeeException("Problem in search..");
                               }
                              
                               
                             
                             return null;
            }
          

               

}
