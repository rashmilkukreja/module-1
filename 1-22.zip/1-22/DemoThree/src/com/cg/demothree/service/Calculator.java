package com.cg.demothree.service;

public class Calculator
{
public int addNumber(int numOne,int numTwo) throws ArithmeticException
{
	throw new ArithmeticException();}
public int subNumber(int numOne,int numTwo)
{
	return numOne-numTwo;}

}
	
	
	
	
	

