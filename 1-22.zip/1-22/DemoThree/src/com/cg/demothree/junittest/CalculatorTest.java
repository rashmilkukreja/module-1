package com.cg.demothree.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.demothree.service.Calculator;

public class CalculatorTest {
    Calculator cal;
	@Before  
	public void beforeTest(){
		//calling before doTest();
		cal=new Calculator();
		
	}
	@Test(expected=ArithmeticException.class)
	public void doTest(){
		assertEquals(6,cal.addNumber(4,2));
	}
	@After
	public void afterTest(){
		cal=null;
		
	}

}
