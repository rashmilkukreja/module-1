package day01;

public class assignment1 
{

	public static void main(String[] args) 
	{
		int sum=0;
		
	int nums[] = new int[] {34,678,58,78};	

		
		for(int index = 0;index <nums.length;index++)
		{
			 sum= sum +nums[index];
			
		
		}
		System.out.println("total sum is"+sum);

}
}
