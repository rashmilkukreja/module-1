package com.capgemini.core.pc;

public class vowelscount
{

	public static void main(String[] args) 
	{
	
	int count=0;
	int c=0,a=0,r=0,i=0,o=0,u=0;
		

		char[] array = new char[] {'a','e','r','i','o','u','r','s','y','w','o'};
		
		 for(int index=0;index<array.length;index++) 
				{switch(array[index])
				{
				case 'a':   count++; a++; continue;
				 case 'e':  count++; r++; continue;
				 case 'i':  count++; i++; continue;
				 case 'o':   count++; o++; continue;
				 case 'u':  count++; u++; continue;
				 default:   c++; continue;
		
				}
				}
		
		
		
		System.out.println("no of vowels" +count);
		System.out.println("no of a= " +a);
		System.out.println("no of e= " +r);
		System.out.println("no of i=" +i);
		System.out.println("no of o=" +o);
		System.out.println("no of u=" +u);
		System.out.println("withot vowels count= " +c);
		System.out.println("total array=" +array.length);
		
		
		
	}

}
