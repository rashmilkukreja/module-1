package com.capgemini.core.pc;

public class assignmentvowels 
{

	public static void main(String[] args) 
	{
	
		  char[] array= new  char[ ] {'w','t','i','u','o','u','y','p'};
		 for(int i=0;i<array.length;i++) 
	switch(array[i])
	{
	case 'a':  System.out.println("its a vowel...... alphabet=" +array[i]); continue;
	 case 'e': System.out.println("its a vowel...... alphabet=" +array[i]); continue;
	 case 'i': System.out.println("its a vowel....... alphabet=" +array[i]); continue;
	 case 'o':  System.out.println("its a vowel...... alphabet=" +array[i]); continue;
	 case 'u':  System.out.println("its a vowel..... alphabet=" +array[i]); continue;
	 default:  System.out.println("its not a vowel.... alphabet=" +array[i]); continue;
	  }
	}
	
}
	
