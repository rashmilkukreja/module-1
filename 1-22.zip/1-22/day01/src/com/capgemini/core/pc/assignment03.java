package com.capgemini.core.pc;

public class assignment03 
{

	public static void main(String[] args)
	{ 
		int[] ids= new int[] {22,3,78,44,11,14,66,77,88,99};
		
		
		for(int index=0;index<ids.length;index++)
		{	if (ids[index]%2==0)
			{
				
					System.out.print( ids[index]+ ",");
		
			}
			else
			{
               
				System.out.print( +ids[index]+ ",");
			}
		}
		
		
	}
}

