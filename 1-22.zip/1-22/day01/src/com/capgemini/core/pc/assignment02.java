package com.capgemini.core.pc;

public class assignment02 {
	public static void main(String[] args)
	{
		
		int[] nums = new int[] {34,678,58,56,87,765,11,78};	

		int min= nums[0];
		int max= nums[0];
		for(int index = 0;index <nums.length;index++)
		{
			{if (min>nums[index])
			{
				min=nums[index];
			}}
			{
				if(max<nums[index])
				{
					max=nums[index];
				}
			}
			
		}
		
		
		System.out.println("min is"+min);
		System.out.println("min is"+max);
		
	}
	
	
	
	
	

}
