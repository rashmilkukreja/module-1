package com.capgemini.core.pc;

public class sort
{

	public static void main(String[] args)
	{
	
		
		int[] array= new int[] {2,3,54,78,67,87,90};
		
		for(int index=0;index<array.length-1;index++)
		{
			if (array[index]>array[index+1])
					{int temp=array[index+1];
							array[index+1]=array[index];
							array[index+1]=temp;
							
							}
		}
			 for (int value : array)
				 System.out.println(value+ " ");
			
			
		}
		}
		

