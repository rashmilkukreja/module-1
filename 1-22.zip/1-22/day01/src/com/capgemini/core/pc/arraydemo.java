package com.capgemini.core.pc;

public class arraydemo 
{

	public static void main(String[] args) 
	{
		int sum=0;
		
	int nums[] = new int[] {34,678,58,78};	

		
		for(int index = 0;index <nums.length;index++)
		{
			 sum= sum +nums[index];
			
		
		}
		System.out.println("total sum is"+sum);

}
}
