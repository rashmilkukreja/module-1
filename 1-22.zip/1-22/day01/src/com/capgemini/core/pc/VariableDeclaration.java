package com.capgemini.core.pc;

public class VariableDeclaration
{
public static void main(String[] args) 
{
	
}
	
	}


