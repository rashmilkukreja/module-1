package com.capgemini.core.pc;

public class loop
{

	public static void main(String[] args) 
	{
		int count=0;
		while (count<10)
		{
			System.out.println((count+1)+") hello world ");
			count++;
		}
	}

}
