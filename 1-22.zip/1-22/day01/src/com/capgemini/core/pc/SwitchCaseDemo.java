package com.capgemini.core.pc;

import java.util.Scanner;

public class SwitchCaseDemo 
{


	public static void main(String[] args)
	{
		
     Scanner console = new Scanner (System.in);
     System.out.println("enter no of day");
     int day=console.nextInt();
      switch (day)
      {
      case 1: System.out.println("its sunday");  break;
      case 2: System.out.println("its monday");  break;
      case 3: System.out.println("its tuesday");  break;
      case 4: System.out.println("its wednesday");  break;
      case 5: System.out.println("its thursday");  break;
      case 6: System.out.println("its friday");  break;
      case 7: System.out.println("its saturday");  break;
      
      default: System.out.println("invalid output"); break;
      
	
	
	
	
      }
	}

}
