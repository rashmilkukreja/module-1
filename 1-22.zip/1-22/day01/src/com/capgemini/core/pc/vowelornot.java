package com.capgemini.core.pc;
import java.util.Scanner;

public class vowelornot 
{

	public static void main(String[] args)
	{
		 Scanner console = new Scanner(System.in);
		 System.out.println("ENTER CHAR");
		 char letter = console.next().toLowerCase().charAt(0);
		 switch(letter)
		 {
		 case 'a':  
		 case 'e': 
		 case 'i': 
		 case 'o':  
		 case 'u':  System.out.println("its a vowel"); break;
		 default:  System.out.println("its a vowel"); break;
		 }

}
}