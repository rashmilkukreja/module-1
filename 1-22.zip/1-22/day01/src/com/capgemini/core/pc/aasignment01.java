package com.capgemini.core.pc;

public class aasignment01 
{
	public static void main(String[] args)
	{
		int num1=34;
	    int num2=45;
	    int num3=67;
	 
	    if( (num1>num2) && ( num1>num3) )
	     {
		 System.out.println("( " +num1+ ") is greatest");
		 }
	     else if( (num2>num1) && (num1>num3))
	       {
	    	 System.out.println("( " +num2+ ") is greatest");
	        }
	     else {
	    	 System.out.println("( " +num3+ ") is greatest");
	     }
	     
     }
}
