
public class day01 {

}
