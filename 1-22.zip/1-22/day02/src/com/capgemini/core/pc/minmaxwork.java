package com.capgemini.core.pc;

public class minmaxwork
{
	

	
	
	
	
}
