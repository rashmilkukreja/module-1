package com.capgemini.core.pc;

public class testemployee {

	public static void main(String[] args) {
		
	
		
		employee emp1 =null;
      emp1 = new employee(100, "rashmil", 123456678);
      employee emp2 =null;
      emp2 = new employee(100, "rashmil", 123456678);

      employee emp3 =null;
      emp3 = new employee(100, "rashmil", 123456678);


     emp1.printDetails();
      
     
 	}
	

}
