package com.capgemini.core.pc;

public class third
{
private String firstName;
private String lastName;
private char gender;




public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public char getGender() {
	return gender;
}
public void setGender(char gender) {
	this.gender = gender;
}






}
