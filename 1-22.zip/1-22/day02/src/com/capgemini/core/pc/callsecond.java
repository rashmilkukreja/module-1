package com.capgemini.core.pc;
import java.util.Scanner;

public class callsecond {

	public static void main(String[] args) 
	{
		second p1=new second();
		Scanner console= new Scanner(System.in);
		System.out.println("enter number");
		int nu=console.nextInt();
		p1.positive(nu);
		
		

	}

	

}
