package com.capgemini.core.pc;

public class callingget
{
	public static void main(String[] args) 
	{
  savingAccount S1 = new savingAccount();
  S1.setAccountId(101);
  S1.setName("joy");
  S1.setBalance(454647);
  S1.withdraw(300);
	
  S1.printDetails();
	
	
	}
	
	
}
