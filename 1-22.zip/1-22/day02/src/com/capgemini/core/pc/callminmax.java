package com.capgemini.core.pc;

import java.util.Scanner;

public class callminmax {

	public static void main(String[] args) {
		Scanner  console = new Scanner(System.in);
		System.out.println("enter radius");
		int radius = console.nextInt();

	}

}
