package com.capgemini.core.pc;

public class area 
{
public static void main(String[] args)
{
	
 calculator calc = new calculator();
	
	
	
}
}