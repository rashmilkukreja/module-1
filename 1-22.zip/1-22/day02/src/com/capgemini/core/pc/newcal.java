package com.capgemini.core.pc;

public class newcal
{
	
		
		public double mul(int a, int b)
		{
			return a*b;
		}
		
		
		
	}


