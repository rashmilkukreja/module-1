package com.capgemini.core.pc;

public class first
{
	private String fname;
	private String lname;
	private int age;
	private char gender;
	private float weight;
	
	
	
	

public String getFname() {
		return fname;
	}





	public void setFname(String fname) {
		this.fname = fname;
	}





	public String getLname() {
		return lname;
	}





	public void setLname(String lname) {
		this.lname = lname;
	}





	public int getAge() {
		return age;
	}





	public void setAge(int age) {
		this.age = age;
	}





	public char getGender() {
		return gender;
	}





	public void setGender(char gender) {
		this.gender = gender;
	}





	public float getWeight() {
		return weight;
	}





	public void setWeight(float weight) {
		this.weight = weight;
	}





public void printvalues()
{System.out.println("person details");
System.out.println("---------------");
System.out.println("first name:" +fname);
System.out.println("last name:" +lname);
System.out.println("gender:" +gender);
System.out.println("age:" +age);
System.out.println("weight:" +weight);
	}
	
	
	
}
