package com.capgemini.core.pc;

public class callthird {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
