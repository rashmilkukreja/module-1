package com.capgemini.core.pc;

public class employee
{

private int id;
private String name;
private float salary;
private static int counter=0;

private static String company;
static{
	company="not yet set";
}

{
	id =-1;
	salary = -1;
	name = "not set";
	counter++;
	}


	public employee(int id, String name, float salary) {
	super();
	this.id = id;
	this.name = name;
	this.salary = salary;
	counter++;
	
}




	public int getId() {
	return id;
}




public void setId(int id) {
	this.id = id;
}




public String getName() {
	return name;
}




public void setName(String name) {
	this.name = name;
}




public float getSalary() {
	return salary;
}




public void setSalary(float salary) {
	this.salary = salary;
}





	public void printDetails()

	{
		
		
		System.out.println("id=" +id);
		System.out.println("name=" +name);
		System.out.println(counter);
		
		
		
		
	}
}
