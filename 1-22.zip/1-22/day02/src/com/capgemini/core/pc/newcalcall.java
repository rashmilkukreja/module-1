package com.capgemini.core.pc;
import java.util.Scanner;

public class newcalcall {
	public static void main(String[] args)
	{
		Scanner  console = new Scanner(System.in);
		System.out.println("enter radius");
		int radius = console.nextInt();
 newcal c1=new newcal();

  double diameter= 2* radius;
  double area = 3.14 * c1.mul(radius, radius);
  double circumfrence= 2* 3.14 * radius;
  System.out.println( diameter);
  System.out.println( area);
  System.out.println( circumfrence);
 
	}
}
