package com.capgemini.core.pc;

public class multidimensionarray {

	public static void main(String[] args) {
		
		int[][] twoDArray = null;
		
		twoDArray = new int[][]{
			{12,15},{23,56},{45,89}
		};
		
//		twoDArray[0][0]=12;
//		twoDArray[0][1]=15;
//		
//		twoDArray[1][0]=18;
//		twoDArray[1][1]=14;
//		
//		twoDArray[2][0]=18;
//		twoDArray[2][1]=10;
		
//		System.out.println(twoDArray[0][0]);
//		System.out.println(twoDArray[0][1]);
//		System.out.println(twoDArray[1][0]);
//		System.out.println(twoDArray[1][1]);
//		System.out.println(twoDArray[2][0]);
//		System.out.println(twoDArray[2][1]);
		
		
		
		for(int row=0;row<twoDArray.length;row++)
		{for(int col=0;col<2;col++)
			System.out.println(twoDArray[row][col]);
		}
		
		
		
		
		
	}

}
