package com.capgemini.core.pc;

public class savingAccount {

	private int accountId;
	private String name;
	private double balance;
	
	
	
	public int getAccountId() {
		return accountId;
	}


	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public double getBalance() {
		return balance;
	}


	public void setBalance(double balance) {
		this.balance = balance;
	}


	public void printDetails()
	{
		System.out.println(accountId + name + balance );
		
	}
	
	
public void withdraw(double amount)
{
    balance = balance - amount;
}
public void deposit(double amount){
	balance=balance+amount;
	}

}
