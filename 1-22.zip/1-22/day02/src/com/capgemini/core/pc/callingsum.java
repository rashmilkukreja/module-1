package com.capgemini.core.pc;

public class callingsum {

	public static void main(String[] args)
	{
		calculator c1= new calculator();
		
		int radius=34;
		double area = 3.14 * c1.mul(radius,radius);
		System.out.println( area);
		

	}

}
