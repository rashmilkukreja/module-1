package com.capgemini.core.pc;

public class second 
{
	private int num;
	
public void positive(int num)
{
	if (num>0)
		System.out.println("number positive");
	else
		System.out.println("number negative");
}
}
