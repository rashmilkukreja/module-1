package com.capgemini.core.pc;

public class callfirst {

	public static void main(String[] args) {
		first f1=new first();
		f1.setFname("Divya");
		f1.setLname("bharathi");
		f1.setGender('f');
		f1.setAge(20);
		f1.setWeight((float) 85.55);
		f1.printvalues();
		

	}

}
