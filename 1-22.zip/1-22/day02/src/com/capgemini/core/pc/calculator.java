package com.capgemini.core.pc;

public class calculator 
{
 
	

	public double mul(int a ,int   b)
	 {
		 return a*b;
		 
	 }

	public void add(int a,int b)
	 {
		 
		int sum= a+b;
		
		System.out.println( sum );
		
	 }
	  
	
	
	
}
