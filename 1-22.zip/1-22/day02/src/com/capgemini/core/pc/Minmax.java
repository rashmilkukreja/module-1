package com.capgemini.core.pc;

public class Minmax
{

	int[] minmax =new int[2];
	public int[]  gtg(int [] arr)
	{
		minmax[0] = minmax[1] = arr[0];
		for(int i=0;i<arr.length;i++)
		{
		
			if(minmax[0]>arr[i])
			{
				minmax[0]=arr[i];
				}
			if(minmax[1]<arr[i])
			{
				minmax[1]=arr[i];
				}
			
		
		}
		return minmax;
		//minmax[0] will return minimum value
		//minmax[1] will return maximum value
	}

}




