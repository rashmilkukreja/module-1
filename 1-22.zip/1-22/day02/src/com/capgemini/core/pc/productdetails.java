package com.capgemini.core.pc;

public class productdetails {
	int no;
	String name;
	int quantity;

}
