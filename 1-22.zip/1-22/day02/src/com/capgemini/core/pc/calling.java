package com.capgemini.core.pc;

public class calling {

	public static void main(String[] args) 
	{
		booksdetails c1 = new booksdetails();
		c1.no = 1002;
		c1.name = "the ramayana";
		
		
		booksdetails c2 = new booksdetails();
		c2.no = 1009;
		c2.name = "xyzzzz";
		
		
		productdetails c3 =  new productdetails();
		c3.no = 1006;
		c3.name = "phone";
		c3.quantity = 5;
		
		productdetails c4 = new productdetails();
		c4.no = 1006;
		c4.name = "phone";
		c4.quantity = 5;
		System.out.println(c2.no + " " + c2.name +" " + c1.no + c1.name + c4.no + c4.quantity );
		
	}

}
