package com.capgemini.core.pc;

public class booksdetails {
	int no;
	String name;

	
		

	}

