package com.capgemini.core.pc;

import java.util.Scanner;

public class arrayaccept {

	public static void main(String[] args) {
		Minmax obj =new Minmax();
		int [] minmax =new int[2];
		
		Scanner s = new Scanner(System.in);

        System.out.println("enter number of elements");

        int n=s.nextInt();

        int arr[]=new int[n];

        System.out.println("enter elements");

        for(int i=0;i<n;i++)
        {
            arr[i]=s.nextInt();

        }

        for(int i: arr)
        { 

            System.out.println(i);

        }
        minmax=obj.gtg(arr);
        System.out.println();
        System.out.println("mimimum number is");
        System.out.print(minmax[0]);
        
        System.out.println(minmax[1]);



	}

}
