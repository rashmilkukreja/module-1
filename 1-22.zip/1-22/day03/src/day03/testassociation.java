package day03;

public class testassociation 
{
public static void main(String[] args)
{
 student student1 = new student(12,"john",5000)	;
 address address1 = new address("abc","pune","mh","india",12344);

student1.setAddress(address1);


System.out.println("name" + student1.getName());
address stuaddress = student1.getAddress();
System.out.println(stuaddress.getCity());
System.out.println( stuaddress.getState());




}
}
