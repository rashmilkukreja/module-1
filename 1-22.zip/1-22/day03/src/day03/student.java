package day03;

public class student 
{
private int roll;
private String name;
private float fees;

private address address;



public int getRoll() {
	return roll;
	

}
public void setRoll(int roll) {
	this.roll = roll;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public float getFees() {
	return fees;
}
public void setFees(float fees) {
	this.fees = fees;
}
public student() {
	super();
}
public student(int roll, String name, float fees) {
	super();
	this.roll = roll;
	this.name = name;
	this.fees = fees;
	
}
public address getAddress() {
	return address;
}
//association
public void setAddress(address address) {
	this.address = address;
}




















}
