package day03;

public class car {

	private String cartype;
	private int carno;
	private car car;
	
	
	
	
	
	
	
	
	
	
	
	

	public car(String cartype, int carno) {
		super();
		this.cartype = cartype;
		this.carno = carno;
	}
	public car() {
		super();
		
	}
	public String getCartype() {
		return cartype;
	}
	public void setCartype(String cartype) {
		this.cartype = cartype;
	}
	public int getCarno() {
		return carno;
	}
	public void setCarno(int carno) {
		this.carno = carno;
	}
	public car getCar() {
		return car;
	}
	public void setCar(car car) {
		this.car = car;
	}
	
	
	
	

	}
