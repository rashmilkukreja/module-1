package day03;

import com.cg.pms.service.IProductService;
import com.cg.pms.service.ProductServiceImpl;

public class call {

	public static void main(String[] args)
	{
		IProductService prodservice=new ProductServiceImpl();
		
		
person p1=new person("rashmil","kukreja");
car c1= new car("jaguar",101);
 p1.setCar(c1);
 
 System.out.println("name= " +p1.getFname());
 
 car cara = p1.getCar();
 System.out.println(cara.getCarno());
 System.out.println( cara.getCartype());
		
		
		
		
		
		
		
	}

}

