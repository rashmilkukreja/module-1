package com.capgemini.core.oop.bankapi;

public class polymorphismdemo 
{
	public static void main(String[] args)
	{
		
		
		BankAccount ba = new BankAccount(101,"john",12000);
		Savingaccount sa = new Savingaccount(102,"amanda",13000);
		CurrentAccount ca = new CurrentAccount(103,"eric",140000);
		
		BankAccount[] bankacc = new BankAccount[3];
		bankacc[0] = ba;
		bankacc[1] = ca;
		bankacc[2] = sa;
		
		
		
//		displayaccountdetails(ba);
//		displayaccountdetails(ca);
//		displayaccountdetails(sa);
//		displayaccountdetails(sa);
//		displayaccountdetails(ca);
	}
		
		
//		public static void displayaccountdetails(BankAccount ba)
//		{
//			System.out.println(ba.getAccountId());
//			System.out.println(ba.getCustomername());
//			System.out.println(ba.getBalance());
//		}
//		
		
		
	
}
