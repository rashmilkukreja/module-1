package com.capgemini.core.oop.bankapi;

public class CurrentAccount extends BankAccount
{

       private double OverDraftLimit;
       private double credit;
       
       
       public double getCredit() {
		return credit;
	}

	public CurrentAccount(int accountId, String CustomerName, int balance) {
       }

       public CurrentAccount(int accountId, String CustomerName, double balance,double OverDraftLimit) {
              super(accountId, CustomerName, balance);
              
              this.OverDraftLimit = OverDraftLimit;
       }

       public double getOverDraftLimit() {
              return OverDraftLimit;
       }

       public void setOverDraftLimit(double overDraftLimit) {
              OverDraftLimit = overDraftLimit;
       } 
       
       @Override
       public void withdraw(double amount) {
    	   if (amount<balance)
    	   {
    		 balance=balance-amount;  
    	   }
    	   else
    	   {double x=amount-balance;
    	   if(x>OverDraftLimit)
    	   {System.out.println("transaction not possible");}
    	   else
    	   {
    		   credit=OverDraftLimit-x;
    		   balance=0;
    	   }
    	   }
             
       }
       
       
       @Override
       public void deposit(double amount)
       {if(getCredit() >0)
       
       { double x=amount-credit;
       balance=balance+x;
    	   credit=0;
       }
       else
       {
    	   balance=balance+amount;
       }
       }
       
}

