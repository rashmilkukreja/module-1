package com.capgemini.core.oop.bankapi;

public class Savingaccount extends BankAccount
{
       private boolean isSalary;
	public double credit;
       
       public Savingaccount(int accountId, String customername, double balance,boolean issalary)
       {
              super(accountId,customername,balance);
              
              
       }

       

       public boolean isSalary() {
              return isSalary;
       }

       public void setSalary(boolean isSalary) {
              this.isSalary = isSalary;
       }

	public String getOverDraftLimit() {
		// TODO Auto-generated method stub
		return null;
	}

}

