package com.capgemini.core.oop.bankapi;

public class BankAccount 
{
       protected int accountId;
       protected String Customername;
       protected double balance;
       
       public BankAccount()
       {
              
       }

       public BankAccount(int accountId, String customername, double balance) {
       
              this.accountId = accountId;
              this.Customername = customername;
              this.balance = balance + 1000;
       }

       public int getAccountId() {
              return accountId;
       }

       public void setAccountId(int accountId) {
              this.accountId = accountId;
       }

       public String getCustomername() {
              return Customername;
       }

       public void setCustomername(String customername) {
              Customername = customername;
       }

       
       


       public double getBalance() {
              return balance;
       }

       public void setBalance(double balance) {
              this.balance = balance;
       }

       public void deposit(double amount)
       {
              balance += amount;
       }
       public void withdraw(double amount)
       {
              if((balance - amount) < 0)
              {
                     System.out.println("Insufficient Amount:  Transaction Denied");
                     return;
                     
              }
              balance -= amount;
       }
       
       
       

}

