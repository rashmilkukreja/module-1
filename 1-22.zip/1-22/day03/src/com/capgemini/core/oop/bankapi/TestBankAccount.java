package com.capgemini.core.oop.bankapi;

public class TestBankAccount {

       public static void main(String[] args) 
       {
           CurrentAccount ca1= new CurrentAccount(101,"John", 50000, 10000);
           
           System.out.println("Account id " + ca1.getAccountId());
           System.out.println("Account name " + ca1.getCustomername());
           System.out.println("Initial balance: " +ca1.getBalance());
           
           System.out.println();
           
           
           
           
           System.out.println("Withdrawing 45000 from account");
           ca1.withdraw(45000);
           
           System.out.println("After withdrawing new balance");
           System.out.println(ca1.getBalance());
           
           System.out.println();
           
           System.out.println("Withdrawing 12000 from account");
           ca1.withdraw(12000);
           
           System.out.println("After withdrawing new balance");
           System.out.println(ca1.getBalance());
           System.out.println("credit="+ca1.getCredit());
           
           
           System.out.println("adding 12000 from account");
           ca1.deposit(12000);
           
           System.out.println(ca1.getBalance());
           System.out.println("credit="+ca1.getCredit());
           
           
           

     /*         CurrentAccount ca1 = new CurrentAccount(1010,"James",6500,50000);
              System.out.println("account id:"+ca1.getAccountId());
              System.out.println("account name:"+ca1.getCustomername());
              System.out.println("balance:"+ca1.getBalance());
              System.out.println("overdraftlimit:"+ca1.getOverDraftlimit());
              System.out.println();
              System.out.println();
           ca1.deposit(2500);
              System.out.println("balance:"+ca1.getBalance());
              System.out.println();
              System.out.println();
              
              ca1.withdraw(40000);
              System.out.println("balance:"+ca1.getBalance());
              System.out.println("overdraftlimit:"+ca1.getOverDraftlimit());
              System.out.println();
              System.out.println();
              
              ca1.deposit(25000);
              System.out.println("balance:"+ca1.getBalance());
              System.out.println("overdraftlimit:"+ca1.getOverDraftlimit());
              System.out.println();
              System.out.println();*/
              
              
              
              
              
       }

}

