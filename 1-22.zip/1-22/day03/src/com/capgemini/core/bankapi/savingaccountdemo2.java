package com.capgemini.core.bankapi;

import com.capgemini.core.oop.bankapi.BankAccount;
import com.capgemini.core.oop.bankapi.CurrentAccount;
import com.capgemini.core.oop.bankapi.Savingaccount;

public class savingaccountdemo2 {

	public static void main(String[] args)
	{
		BankAccount[] accounts = new BankAccount[4];
		accounts[0] = new BankAccount(101,"john",12000);
		accounts[1] = new Savingaccount(102,"eric",15000,true);
		accounts[2] = new CurrentAccount(104,"ellen",32000,1000);
		accounts[3] = new CurrentAccount(101,"amanda",1245600,1000);
		printaccountdetails(accounts);

	}
	public static void printaccountdetails(BankAccount[] ba)

	{
		for(int index=0;index<ba.length;index++)
		{
			System.out.println("id" +ba[index].getAccountId());
			System.out.println("id" +ba[index].getCustomername());
			System.out.println("id" +ba[index].getBalance());
			if (ba[index] instanceof CurrentAccount)
				{
				CurrentAccount ca=(CurrentAccount)ba[index];
				System.out.println("overdraftlimit="+ca.getOverDraftLimit());
				}
			
			if (ba[index] instanceof Savingaccount)
			{
				
				
			Savingaccount ca=(Savingaccount)ba[index];
			System.out.println("issalary="+ca.isSalary());
			}
		
			System.out.println();
			
			
		}
	}
}
