package com.cg.demofour.ui;

import com.cg.demofour.service.MyCalculator;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   MyCalculator  add=(num1,num2)->{
	   return num1+num2;
   };
	
   MyCalculator  sub=(num1,num2)->{
	   return num1-num2;
   };
   System.out.println("addition of two" +add.Calculator(10, 20));
   System.out.println("sub of" +sub.Calculator(30,10));
	}
}
