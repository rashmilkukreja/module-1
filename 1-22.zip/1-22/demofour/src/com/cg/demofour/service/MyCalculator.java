package com.cg.demofour.service;
@FunctionalInterface
public interface  MyCalculator
{
public double Calculator(double numOne,double numTwo);
}
