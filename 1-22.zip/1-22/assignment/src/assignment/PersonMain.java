package assignment;

public class PersonMain {

	public static void main(String[] args) {
		
person p1=new person("divya","bharathi",36790780);
p1.setperson();
p1.gender1(gender.female);
System.out.println("fname="+p1.getFirstName()+"lname="+p1.getLastName());

	}

}
