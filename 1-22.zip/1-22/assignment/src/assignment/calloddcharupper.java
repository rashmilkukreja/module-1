package assignment;

import java.util.Scanner;

public class calloddcharupper
{ public static void main(String[] args)
	{
	
	Scanner console=new Scanner(System.in);
	System.out.println("enter string");
	String line=console.nextLine();
	
	oddcharuppercase o1=new oddcharuppercase(line);
	
	
	
	
	
	
	
	}
}
