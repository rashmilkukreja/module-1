package assignment;
enum gender{male,female}

public class person
{
private String firstName;
private String lastName;
//private char gender;
private double number;
public void gender1(gender gender)
{
	switch(gender)
	{
	case male:System.out.println("male");
	case female: System.out.println("female");
	}}
public person(String firstName, String lastName, double number) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
//	this.gender = gender;
	this.number = number;
}
public double getNumber() {
	return number;
}
public void setNumber(double number) {
	this.number = number;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
//public char getGender() {
//	return gender;
//}
//public void setGender(char gender) {
//	this.gender = gender;
//}
public person(String firstName, String lastName, char gender) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
//	this.gender = gender;
}
public person() {
	super();
	// TODO Auto-generated constructor stub
}
public void setperson() {
	// TODO Auto-generated method stub
	
}

























}
