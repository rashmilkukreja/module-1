package assignment;

public class oddcharuppercase
{

	

	public  oddcharuppercase(String line) 
	{
		String temp="";
		String newword="";
			
				for(int i=0;i < line.length() ; i++)
				{
					if(i % 2 ==0)
					{
						temp="";
						temp+=line.charAt(i);
						temp=temp.toUpperCase();
						newword+=temp;
						
					}
					else
					{
						temp="";
						temp+=line.charAt(i);
						temp=temp.toLowerCase();
						newword+=temp;
					}
				}
				System.out.println(newword);
}

	
}