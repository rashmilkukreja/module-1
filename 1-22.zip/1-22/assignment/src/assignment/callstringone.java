package assignment;

import java.util.Scanner;

public class callstringone {

	public static void main(String[] args) 
	{Scanner console = new Scanner(System.in);
		
		System.out.println("enter string");
		String line=console.nextLine();
		System.out.println("string is "+line);
		
		stringone s1= new stringone(line);
	
	}
}


