package assignment;

public class stringone 
{
private String line;


	

public stringone() {
	super();
	
}




public stringone(String line) 
{
	char[] letters=line.toCharArray();
	for(int index=0;index<letters.length;index++)
	{
		
		
	
	for(int i=0;i<letters.length;i++)
	{if(letters[index]==letters[i+1])
	{     
	System.out.print( letters[index]);
	
	}
	else 
		System.out.println(letters[i]);
		
	}
	
}
	
}

}

