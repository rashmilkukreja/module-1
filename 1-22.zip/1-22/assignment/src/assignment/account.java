package assignment;

public class account
{ 
	
	private long accNum;
	private double balance;
	
	
	
	
	
	
	public account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public account(long accNum, double balance) {
		super();
		this.accNum = accNum;
		this.balance = balance;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
	
	
	
	
	
	
	
	
	
	
		
	
	
}
