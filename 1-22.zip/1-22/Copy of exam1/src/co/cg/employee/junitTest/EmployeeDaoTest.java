package co.cg.employee.junitTest;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.employee.exception.exception;

import co.cg.employee.dao.EmployeeDaoImpl;
import co.cg.employee.dto.employee;


public class EmployeeDaoTest {
	employee prod=null;
	EmployeeDaoImpl prodDao=null;
@Before
public void callBefore()
{ prod=new employee();
//prod.setProductName("Aaaa");
//prod.setProductPrice(1234);
//prod.setProductDes("hdhfd");
prodDao=new EmployeeDaoImpl();
	}

@Test
public void myTestCase() throws exception{}
//{ assertEquals(1018,prodDao.addProduct(prod));
//	}
@After
public void callAfter(){
}


}
