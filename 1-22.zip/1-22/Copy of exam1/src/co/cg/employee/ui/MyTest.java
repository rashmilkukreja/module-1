package co.cg.employee.ui;

import java.util.Scanner;

public class MyTest {
	public static void main(String[] args)
	{
		
		

		int choice =0;

do{
	printDetail();
	Scanner scr=new Scanner(System.in);
	System.out.println("enter choice");
	choice=scr.nextInt();
	
	switch(choice)
	{
	case 1://insert customer n purcahae
		break;
	case 2: //update mobile
		break;
	case 3: //view all mobile
		break;
	case 4://delete mobile details
		break;
	case 5: //search mobile based on price range"
		break;
	case 6: 
		System.exit(0);
		break;
	
	
	
	
	
	
	
	
	
	}
}while(choice!=6);
	}
	public static void printDetail(){
		System.out.println("*******************************************************************************");
		System.out.println("1) insert customer and purchase");
		System.out.println("2) update mobile");
		System.out.println("3) view all mobile");
		System.out.println("4) delete mobile details");
		System.out.println("5)search mobile based on price range");
		System.out.println("6) exit");
		System.out.println("******************************************************************************");
		
		
		
	}	
}