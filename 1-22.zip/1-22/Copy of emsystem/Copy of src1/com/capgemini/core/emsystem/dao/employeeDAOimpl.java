package com.capgemini.core.emsystem.dao;

import java.util.ArrayList;



import com.capgemini.core.emsystem.beans.Employee;
import com.capgemini.core.emsystem.exception.EmployeeException;

public class employeeDAOimpl implements IEmployeeDAO 
{ private ArrayList<Employee> employeeDB = new ArrayList<>();

	@Override
	public void addEmployee(Employee employee) throws EmployeeException {
		if (employeeDB.contains(employee))
		{
			throw new EmployeeException("EMPLOYEE ALREADY EXIST"+employee.getId());
		}
		employeeDB.add(employee);
		
	}

	@Override
	public Employee getemployee(int id) throws EmployeeException
	{
		Employee emp=new Employee();
		emp.setId(id);
		if(employeeDB.contains(emp))
		{
			int index = employeeDB.indexOf(emp);
			emp=employeeDB.get(index);
		}
		else
		{
			throw new EmployeeException("Employee not found with id"+id);
		}
		return emp;	
	}

	@Override
	public void UpdateEmployee(Employee employee) throws EmployeeException
	{
		int index =employeeDB.indexOf(employee);
		employeeDB.remove(index);
		employeeDB.add(index,employee);
	}

	@Override
	public void removeEmployee(int id) throws EmployeeException {
		Employee emp=new Employee();
		emp.setId(id);
		if(employeeDB.contains(emp))
		{
			employeeDB.remove(emp);
		}
		else
		{
			throw new EmployeeException("Employee not found with id"+id);
		}
		
	}

	@Override
	public ArrayList<Employee> getEmployee() throws EmployeeException
	{ if(employeeDB.isEmpty())
	{ throw new EmployeeException("no employee in database");}
		return employeeDB;
	}

}
