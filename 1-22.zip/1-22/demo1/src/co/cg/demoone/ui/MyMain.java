package co.cg.demoone.ui;

import java.io.FileInputStream;

import java.io.IOException;
import java.util.Properties;

public class MyMain {

	public static void main(String[] args)
	{
		try {
			FileInputStream fileRead = new FileInputStream("oracle.properties");
			Properties prop = new Properties();
			prop.load(fileRead);
			String jname=prop.getProperty("username");
			String jpass=prop.getProperty("password");
			System.out.println("username="+jname+ " and password=" +jpass);
		    } 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("error in reading..........");
		}

	}

}
