package com.capgemini.core.oop;
enum cupsize
{
	small,regular,large
	}
class cafecoffeeday
{
	
public void ordercoffee(cupsize cupsize)
{
 switch( cupsize)
 { 
 case small: System.out.println("tou order coffee small");
 case regular: System.out.println("tou order coffee small");
 case large: System.out.println("tou order coffee large");
 default: System.out.println("please enter valid");

 }
}

}

public class testccd {

	public static void main(String[] args) {
		cafecoffeeday ccd = new cafecoffeeday();
		ccd.ordercoffee(cupsize.small);
	}

}
