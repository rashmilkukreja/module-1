package com.capgemini.core.oop;

public abstract interface drawable {
 int BORDER = 12;
 public abstract void drawcolored();
 
}
