package com.capgemini.core.oop;

public abstract class shape {
	
	public  abstract double getarea();
	
	
	
	

}
