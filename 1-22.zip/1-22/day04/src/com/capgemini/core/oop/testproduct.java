package com.capgemini.core.oop;

public class testproduct {

	public static void main(String[] args) {
		product p1=new product(101,"htc",12000);

		product p2=new product(101,"htfmfgj",12000);
		
		System.out.println(p1.hashCode());
	System.out.println(p2.hashCode());
	
	
		System.out.println(p1.toString());
		System.out.println(p2.toString());
		
////		
////	
		
//		System.out.println(p1);
//		
//		System.out.println(p2);
//		
//		
//		
//		
		
		
		
		
		
		
		
		System.out.println(p1.equals(p2));
		
		
		
		
		
		
		
		
}

}
