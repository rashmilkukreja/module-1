package com.capgemini.core.oop;

public class stringclassdemo
{
	public static void main(String[] args)
	{
		
		String msg="rashmil.kukreja@gmail.com";
		
		String newmsg=msg.substring(msg.indexOf("@")+1,msg.lastIndexOf("."));
		System.out.println(newmsg);
		
	}

}
