package com.capgemini.core.oop;

public  class circle extends shape implements drawable
{
 private static final double pi = 3.14;
protected int radius;
private double area;



public circle(int radius) {
	super();
	this.radius = radius;
}

  public int getRadius() {
	return radius;
}

public void setRadius(int radius)
{
	this.radius = radius;
}



@Override
public double getarea() {
	area= pi * radius*radius;
	return area;
}
@Override
	public void drawcolored() {
	
		System.out.println("drawing color is red");
	}
 
}
