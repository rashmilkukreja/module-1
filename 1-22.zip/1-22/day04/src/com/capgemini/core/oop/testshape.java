package com.capgemini.core.oop;

public class testshape {
	public static void main(String[] args)
	{
		
		circle circ = new circle(3);
		System.out.println(circ.getarea());
		
	}

}
