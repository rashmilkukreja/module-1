package com.capgemini.core.collections;

import java.util.ArrayList;


public class arraylistdemo 
{
public static  void main(String[] args){
	employee emp = new employee(101,"john",1200);
	String str = "hello world";
	taxcalculator calc = new taxcalculator();
	String str2 = "hello world";
	employee emp2 = new employee(101,"john",1200);
	
	ArrayList<E> mylist = new arraylist();
	mylist.add(emp);
	mylist.add(str);
	mylist.add(calc);
	mylist.add(str2);
	mylist.add(emp2);
	
	
	
	
	
	
	
	
	
	
	
}
}
