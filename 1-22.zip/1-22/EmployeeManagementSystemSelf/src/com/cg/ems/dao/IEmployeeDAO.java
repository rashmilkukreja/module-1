package com.cg.ems.dao;

import java.util.ArrayList;

import com.cg.ems.exception.EmployeeException;
import com.cg.ems.dto.Employee;

public interface IEmployeeDAO
{
	public int addEmployee(Employee empl) throws EmployeeException;
	//public in updateEmployee(int id) throws EmployeeException;
	public ArrayList<Employee> viewAll() throws EmployeeException;
	public void removeEmployee(int empId) throws EmployeeException;
	Employee searchEmployee(int empid) throws EmployeeException;
	public int updateEmployee(int empId, String ename) throws EmployeeException;

}

