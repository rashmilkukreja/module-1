package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmployeeServiceImpl;
import com.cg.ems.util.DbUtil;
import com.cg.ems.dto.Employee;

public class EmployeeDaoImpl implements IEmployeeDAO 
{
private static final Logger mylog = Logger.getLogger(EmployeeDaoImpl.class);
	Connection conn=null;
	PreparedStatement pstm=null;
	
	@Override
	public int addEmployee(Employee empl) throws EmployeeException 
	{
		int status=0;
		conn=DbUtil.getConnection();
		String query="Insert into Employeedb values(?,?,?,?)";
		try {
			pstm=conn.prepareStatement(query);
			pstm.setInt(1,empl.getEmpId());
			pstm.setString(2,empl.getEmpName());
			pstm.setDouble(3, empl.getSalary());
			pstm.setString(4, empl.getDes());
			status = pstm.executeUpdate();
			mylog.info("data inserted.....");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally
		{
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new EmployeeException("Problem in insert..");
			}
			
		}
		
		
	return status;
	}
	

	@Override
	public int updateEmployee(int empid , String ename) throws EmployeeException {
		// TODO Auto-generated method stub
		int  status=0;
//		Employee emp1 = new Employee();
		try {
			
			
			conn=DbUtil.getConnection();
			String queryfive="update employeedb set emp_name=? where emp_id= ?";
			pstm =conn.prepareStatement(queryfive);
			pstm.setString(1,ename);
			pstm.setInt(2,empid);
			status = pstm.executeUpdate();
		} catch (EmployeeException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return status;
		
		
		
	}

	@Override
	public ArrayList<Employee> viewAll() throws EmployeeException {
		ArrayList<Employee> myList = new ArrayList<Employee>();
		conn=DbUtil.getConnection();
		String querytwo="Select emp_id,emp_name,emp_sal,emp_des from employeedb";
		try {
			pstm=conn.prepareStatement(querytwo);
			ResultSet res=pstm.executeQuery();
			System.out.println("View all working...");
			while(res.next())
			{
				Employee em=new Employee();
				em.setEmpId(res.getInt("emp_id"));
				em.setEmpName(res.getString("emp_name"));
				em.setSalary(res.getDouble("emp_sal"));
				em.setDes(res.getString("emp_des"));
			
				
				myList.add(em);
			}
			
			
		} catch (SQLException e) {
			throw new EmployeeException("Problem in view..");
			//e.printStackTrace();
		}
		
		finally
		{
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		return myList;
	}

	
	
	
	
	@Override
	public void removeEmployee(int empId) throws EmployeeException {
		
		try {
			conn = DbUtil.getConnection();
			String queryfour = "Delete  from employeedb where emp_id=?";
			pstm = conn.prepareStatement(queryfour);
			System.out.println("DATA DELETED1");
			pstm.setInt(1,empId);
			System.out.println("DATA DELETED2");
		pstm.executeUpdate();
		System.out.println("DATA DELETED3");
			//pstm.executeUpdate();
			
			} 
		
		catch (EmployeeException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException("Problem in search..");
		}
		finally
		{
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		
		
	}


	@Override
	public Employee searchEmployee(int empid) throws EmployeeException
	{
		Employee esearch=null;
		try {
			conn=DbUtil.getConnection();
			String querythree="Select emp_name,emp_sal,emp_des from employeedb where emp_id=?";
					pstm=conn.prepareStatement(querythree);
					pstm.setInt(1,empid);
					ResultSet restwo = pstm.executeQuery();
					while(restwo.next())
					{
						esearch = new Employee();
						esearch.setEmpName(restwo.getString("emp_name"));
						esearch.setDes(restwo.getString("emp_des"));
						esearch.setSalary(restwo.getDouble("emp_sal"));
						
						
					}
					
		} 
		catch (EmployeeException | SQLException e) 
		{
			e.printStackTrace();
			
			throw new EmployeeException("Problem in search..");
			
			
		}
		
		
		finally
		{
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
		}
		return esearch;
	}
	

}


