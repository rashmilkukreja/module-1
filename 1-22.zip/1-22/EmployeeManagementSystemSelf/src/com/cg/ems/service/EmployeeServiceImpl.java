package com.cg.ems.service;

import java.util.ArrayList;

import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dao.IEmployeeDAO;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.dto.Employee;

public class EmployeeServiceImpl implements IEmployeeService 
{
	IEmployeeDAO empDao = new EmployeeDaoImpl();
	
	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.addEmployee(emp);
	}

	@Override
	public int updateEmployee(int empId , String ename) throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.updateEmployee(empId , ename);
	}

	@Override
	public ArrayList<Employee> viewAll() throws EmployeeException {
		
		return empDao.viewAll();
	}

	@Override
	public void removeEmployee(int empId) throws EmployeeException {
		
		empDao.removeEmployee(empId);
	}
	
	@Override
	public Employee searchEmployee(int empid) throws EmployeeException
	{
		return empDao.searchEmployee(empid);
	}

	
	
	

}
