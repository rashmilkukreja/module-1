package com.cg.ems.juittest;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;

public class EmployeeDaoTest {

	Connection conn=null;
	PreparedStatement pstm = null;
	Employee emp = null;
	EmployeeDaoImpl empDao = null;
	
	@Before
	public void callBefore()
	{
		emp = new Employee();
		emp.setEmpName("Monika");
		emp.setSalary(546);
		emp.setDes("ceo");
		empDao = new EmployeeDaoImpl();
	}
	
	
	
	@Test
	public void test() throws EmployeeException 
	{
		assertEquals(1,empDao.addEmployee(emp));
	}

	
	
	@After
	public void callAfter()
	{
		
	}
	
}
