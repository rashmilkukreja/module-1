package co.capgemini.core.collections;

import java.io.File;

public class filedemo {
	public static void main(String[] args)
	{
	File file = new File("D:\\corejavaTraining\\collection.java");	
		
		if (file.exists())
		{
		System.out.println(file.isHidden());	
		System.out.println(file.canRead());	
		System.out.println(file.canWrite());	
		System.out.println(file.getPath());	
		}
		else
		{
			System.out.println("file not found");
		}
		
		
		
		
		
		
		
	}

}
