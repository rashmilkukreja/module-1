package co.capgemini.core.collections;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class numberofwords 
{ public static void main(String[] args) 
{
    FileReader fileReader = null;
    int count=0;
    
    try 
    {
           fileReader   = new FileReader("D:\\rashmil\\New Text Document.txt");
           int dataRead = fileReader.read();
           
           for(int index=0;index>dataRead;index++)
        	   {while(dataRead != -1)
           {
                 System.out.println( (char)dataRead );
                 
                 dataRead = fileReader. read();
                 
                 count++;
           }}
           
    }
    catch (FileNotFoundException e) {
           
           e.printStackTrace();
    }
    catch(IOException e)
    {
           e.printStackTrace();
    }
    finally
    {
           try
           {
                 fileReader.close();
           }
                 catch(IOException e)
                 {
                        e.printStackTrace();
                 }
    }
    }
}

	
	
	
	
	
	
	
	
	
	

