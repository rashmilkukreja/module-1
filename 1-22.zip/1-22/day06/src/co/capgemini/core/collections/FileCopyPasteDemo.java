package co.capgemini.core.collections;

public class FileCopyPasteDemo
{

}
