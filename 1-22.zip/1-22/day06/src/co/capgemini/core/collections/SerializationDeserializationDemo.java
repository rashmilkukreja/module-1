package co.capgemini.core.collections;

public class SerializationDeserializationDemo 
{

}
