package co.capgemini.core.collections;

import java.util.ArrayList;

public class WrapperClassesDemo 
{
public static void main(String[] args)
{
	int num=23;
	Integer intObj = new Integer(num);
	int num2=intObj.intValue();
	Integer intobj2=12;
	int num3=intobj2;
	













}
}
