package co.capgemini.core.collections;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args)
	{
		
		Map<String, String>mobileDetails=new HashMap<String,String>();
		mobileDetails.put("anderoid","6");
		mobileDetails.put("PROCESSOR","2Ghz");
		mobileDetails.put("BATTERY","3000mAh");
		mobileDetails.put("CAMERA","12mp");
		
		System.out.println(mobileDetails.get("anderoid"));
		
		Set<String> setofkeys=mobileDetails.keySet();
	System.out.println(setofkeys);
		
	
	
	Collection<String> values=mobileDetails.values();
		System.out.println(values);
		
		
		
		Set keyValuePair=mobileDetails.entrySet();
		System.out.println(keyValuePair);
		
		
		
	}

}
