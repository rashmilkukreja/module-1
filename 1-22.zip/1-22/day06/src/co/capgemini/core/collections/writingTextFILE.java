package co.capgemini.core.collections;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class writingTextFILE {

       public static void main(String[] args)
       {
              Scanner console = new Scanner(System.in);
              
              System.out.println("enter your name");
              String name = console.next();
              
              System.out.println("enter your mail ");
        String email = console.next();
        
       // perform io operation
        
        BufferedWriter bufferedWriter =null;
        
        try {
                     bufferedWriter = new BufferedWriter(new FileWriter("D:\\corejavatraining\\Greetings\\src\\com\\capgemini\\core\\classess\\myfile.txt"));
                     
                     bufferedWriter.write("Name = "+name);
                     bufferedWriter.newLine();
                     bufferedWriter.write("EMAIL= "+email);
                     bufferedWriter.newLine();
              } catch (IOException e) {
                     // TODO Auto-generated catch block
                     e.printStackTrace();
                     
              }
        finally
        {
              try {
                           bufferedWriter.close();
                     } catch (IOException e) {
                           // TODO Auto-generated catch block
                           e.printStackTrace();
                     }
        }
        

       }

}

