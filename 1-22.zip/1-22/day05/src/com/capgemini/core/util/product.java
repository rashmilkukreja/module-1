package com.capgemini.core.util;

public class product {
	protected int id;
	protected String model;
protected float price;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getModel() {
	return model;
}
public void setModel(String model) {
	this.model = model;
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}
public product() {
	super();
	// TODO Auto-generated constructor stub
}
public product(int id, String model, float price) {
	super();
	this.id = id;
	this.model = model;
	this.price = price;
}

@Override
public int hashCode()
{
	return id;
}
private int compareto(Object arg0) 
{
product p2 =(product)arg0;	
return id-p2.getId();

}
}
