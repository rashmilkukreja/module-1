package com.capgemini.core.util;

import java.util.HashSet;
import java.util.Iterator;




public class hashtagdemo {
	public static void main(String[] main)
	{
		
	
	HashSet product = new HashSet();
	product.add(new product(101,"sony",500));
	product.add(new product(102,"sony..",4500));
	product.add(new product(103,"sony hgh",700));
	
	Iterator it2 = product.iterator();
	while(it2.hasNext())
	{Object obj=it2.next();
	System.out.println(obj);
	}

}
}