package com.capgemini.core.util;

public class genericsdemo {

	public static void main(String[] args) {
		

	}

}
