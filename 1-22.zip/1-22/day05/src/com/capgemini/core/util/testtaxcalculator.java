package com.capgemini.core.util;

public class testtaxcalculator 
{
	public static void main(String[] args)
	{
		
		float salary=2345;
//		float taxableamount = taxcalculator.gettaxonsalary();
//		System.out.println("taxable amount" +);
//		
		
		
	try{taxableamount = taxcalculatot.gettaxonsalary(salary);
	}	
		
		catch (exception e)
		e.printstacktrace();
		
		
	}
	System.out.println()
	
	
}
