package day05;

import java.util.*;

public class userinterfaction
{
public static void main(String[] args)
{
	Scanner scan = new Scanner(System.in);
	Employee emp=new Scanner(System.in);
	System.out.println("ENTER EMPLOYEE NAMME");
	emp.setName(scan.nextLine());
	System.out.println("enter employee id");
	emp.setid(scan.nextInt());
	System.out.println("enter salary");
	emp.setsalary(scan.nextFloat());
	emp.printdetails();
	}
}
