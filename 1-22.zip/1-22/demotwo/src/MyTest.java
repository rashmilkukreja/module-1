

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class MyTest {

	public static void main(String[] args) 
	{
		
		
		try {
			FileInputStream fileRead= new FileInputStream("oracle.properties");
			Properties pros=new Properties();
			pros.load(fileRead);
			
			String driver=pros.getProperty("oracle.driver");
			String url=pros.getProperty("oracle.url");
			String uname=pros.getProperty("oracle.username");
			String upass=pros.getProperty("oracle.password");
			
			Class.forName(driver);
			Connection conn=DriverManager.getConnection(url, uname, upass);
			System.out.println("connection established....");
			
		} catch (IOException | ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("no connection...");
		}
		
		
		
		

	}

}
