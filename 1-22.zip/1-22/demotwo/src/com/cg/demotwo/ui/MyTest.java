package com.cg.demotwo.ui;


import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

public class MyTest {

	public static void main(String[] args) 
	{
		
//		Scanner scr=new Scanner(System.in);
//		System.out.println("enter id");
//		int id=scr.nextInt();
//		System.out.println("enter product name");
//		String pName=scr.next();
//		System.out.println("enter product price");
//		double price=scr.nextDouble();
//		System.out.println("enter descriptions");
//		String des=scr.next();
		try {
			FileInputStream fileRead= new FileInputStream("oracle.properties");
			Properties pros=new Properties();
			pros.load(fileRead);
			
			String driver=pros.getProperty("oracle.driver");
			String url=pros.getProperty("oracle.url");
			String uname=pros.getProperty("oracle.username");
			String upass=pros.getProperty("oracle.password");
			
			Class.forName(driver);
			
			Connection conn=DriverManager.getConnection(url, uname, upass);
			System.out.println("connection established....");
			String query="SELECT prod_id,prod_name,prod_price,prod_des FROM PRODUCTDB";
			PreparedStatement pstm=conn.prepareStatement(query);
			ResultSet res=pstm.executeQuery();
			
			while(res.next())
			{
				System.out.println(res.getInt("prod_id"));
				System.out.println(res.getString("prod_name"));
				System.out.println(res.getDouble("prod_price"));
				System.out.println(res.getString("prod_des"));
				
			}
			
//			String query="INSERT INTO PRODUCTDB VALUES(?,?,?,?)";
//			PreparedStatement pstm=conn.prepareStatement(query);
//			pstm.setInt(1,id);
//			pstm.setString(2,pName);
//			pstm.setDouble(3,price);
//			pstm.setString(4,des);
//			
//			int status=pstm.executeUpdate();
//			System.out.println(status);
//			
			
		} catch (IOException | ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("no connection...");
			
		}
		
		
		
		

	}
	public void addProduct(){
		Connection conn=null;
		Scanner scr=new Scanner(System.in);
		System.out.println("enter id");
		int id=scr.nextInt();
		System.out.println("enter product name");
		String pName=scr.next();
		System.out.println("enter product price");
		double price=scr.nextDouble();
		System.out.println("enter descriptions");
		String des=scr.next();
		String query="INSERT INTO PRODUCTDB VALUES(?,?,?,?)";
	
		PreparedStatement pstm;
		try {
			pstm = conn.prepareStatement(query);
			 pstm.setInt(1,id);
		     pstm.setString(2,pName);
		    pstm.setDouble(3,price);
		   pstm.setString(4,des);

		   int status=pstm.executeUpdate();
		    System.out.println(status);
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    
	}

}
