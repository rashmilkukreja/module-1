package com.capgemini.core.emsystem.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;








import java.util.List;

import com.capgemini.core.emsystem.beans.Employee;
import com.capgemini.core.emsystem.exception.EmployeeException;

public class employeeDAOimpl implements IEmployeeDAO 
{ private ArrayList<Employee> employee = new ArrayList<>();
Connection con=null;
PreparedStatement pstm=null;

	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		int status=0;
		con=com.capgemini.core.emsystem.util.DbUtil.getConnection();
		
		String query="INSERT INTO employee VALUES(?,?,?)";
		
			try {
				pstm=con.prepareStatement(query);
				pstm.setInt(1,employee.getId());
				pstm.setString(2,employee.getName());
				pstm.setDouble(3, employee.getSalary());
				
				
			status=pstm.executeUpdate();}
			
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new EmployeeException("problem in insert");
			}
			finally{
				try{
				pstm.close();
				con.close();
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			} 
			
	return status;

	}

	@Override
	public List<Employee> getemployee() throws EmployeeException
	{
List<Employee> myList=new ArrayList<Employee>();
		
		con=com.capgemini.core.emsystem.util.DbUtil.getConnection();
		String queryTwo="SELECT * from employee";
		try {
			pstm=con.prepareStatement(queryTwo);
			ResultSet res=pstm.executeQuery();
			
			while(res.next()){
				Employee pr=new Employee();
				pr.setId(res.getInt("prod_id"));
				pr.setName(res.getString("prod_name"));
				pr.setSalary(res.getDouble("prod_price"));
				
				
				myList.add(pr);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try{
			pstm.close();
			con.close();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException("problem in show");
		}
		}
		return myList;
		
	}

	@Override
	public void UpdateEmployee(Employee employee) throws EmployeeException
	{
		
	}

	@Override
	public void removeEmployee(int id) throws EmployeeException {
		
		
	}

	@Override
	public ArrayList<Employee> getEmployee() throws EmployeeException
	{
		return employee;

}
}
