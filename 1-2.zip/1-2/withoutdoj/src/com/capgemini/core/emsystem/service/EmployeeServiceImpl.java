package com.capgemini.core.emsystem.service;

import java.util.ArrayList;



import java.util.List;

import com.capgemini.core.emsystem.beans.Employee;
import com.capgemini.core.emsystem.dao.IEmployeeDAO;
import com.capgemini.core.emsystem.dao.employeeDAOimpl;
import com.capgemini.core.emsystem.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {
	
	
	
	IEmployeeDAO empDAO = new employeeDAOimpl();
	
	
	
	
	

	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		return empDAO.addEmployee(employee);
	}

	@Override
	public  List<Employee> getemployee() throws EmployeeException {
		return empDAO.getemployee();
	}

	@Override
	public void UpdateEmployee(Employee employee) throws EmployeeException {
		 empDAO.UpdateEmployee(employee);

	}

	@Override
	public void removeEmployee(int id) throws EmployeeException{
		 empDAO.removeEmployee(id);
	}

	@Override
	public ArrayList<Employee> getEmployees() throws EmployeeException {
		return empDAO.getEmployee();
	}

	

	
				
	}


