package com.capgemini.core.emsystem.dao;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.core.emsystem.beans.Employee;
import com.capgemini.core.emsystem.exception.EmployeeException;

public interface IEmployeeDAO 
{
public int addEmployee(Employee employee) throws EmployeeException;
public List<Employee> getemployee() throws EmployeeException;
public void UpdateEmployee(Employee employee) throws EmployeeException;
public void removeEmployee(int id) throws EmployeeException;
public ArrayList<Employee> getEmployee() throws EmployeeException;

}
