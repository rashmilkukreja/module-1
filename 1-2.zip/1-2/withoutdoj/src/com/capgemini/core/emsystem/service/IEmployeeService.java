package com.capgemini.core.emsystem.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.core.emsystem.beans.Employee;
import com.capgemini.core.emsystem.exception.EmployeeException;

public interface IEmployeeService
{

	
	
	
	
	public int addEmployee(Employee employee) throws EmployeeException;
	public  List<Employee> getemployee() throws EmployeeException;
	public void UpdateEmployee(Employee employee) throws EmployeeException;
	public void removeEmployee(int id) throws EmployeeException;
	public ArrayList<Employee> getEmployees() throws EmployeeException;
	

	
	
	
	
}
