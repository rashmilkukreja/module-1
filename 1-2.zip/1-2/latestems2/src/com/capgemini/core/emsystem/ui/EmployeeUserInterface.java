package com.capgemini.core.emsystem.ui;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;







import com.capgemini.core.emsystem.beans.Employee;
import com.capgemini.core.emsystem.exception.EmployeeException;
import com.capgemini.core.emsystem.service.EmployeeServiceImpl;
import com.capgemini.core.emsystem.service.IEmployeeService;

public class EmployeeUserInterface
{
	//loose coupling
	IEmployeeService empService = new EmployeeServiceImpl();

	public void emsystemOperation()
	{
		Scanner console = new Scanner(System.in);


		int choice=0;
		System.out.println("1)add employee");
		System.out.println("2)get employee");
		System.out.println("3)update employee");
		System.out.println("4)remove employee");
		System.out.println("5)view all employee");
		System.out.println("6)exit application");

		System.out.println("enter your choice");

		choice= console.nextInt();
		switch(choice)
		{

		case 1:
			System.out.println("\n\n");
				System.out.println("enter employee id");
			int id=console.nextInt();

			System.out.println("ENTER EMPLOYEE NAME");
			String name = console.next();

			System.out.println("enter salary");
			
			double salary = console.nextDouble();

			
			System.out.println("enter doj");
			Date doj=console.nextDate();

			

			
			//instantiating n initializing employee object

			Employee employee = new Employee();

				employee.setId(id);
			employee.setName(name);
			employee.setSalary(salary);
			employee.setDateofjoining(doj);
			//pass employee details(employee object) to service layer
		
			try {

				int empId=empService.addEmployee(employee);
				System.out.println("employee added succesfully..Id="+empId);
			} 
			catch (EmployeeException e)
			{

				e.printStackTrace();
				System.out.println("something went wrong while adding" +e.getMessage());
			}


			break;

		case 2:   System.out.println("\n\n");
		System.out.println("enter id");
		id=console.nextInt();

		try{
			Employee emp1= empService.getemployee(id);

			System.out.println("id:"+emp1.getId());
			System.out.println("name:"+emp1.getName());
			System.out.println("salary:"+emp1.getSalary());
			System.out.println("doj:"+emp1.getDateofjoining());

			System.out.println("\n\n\n");
		}
		catch(EmployeeException e1)
		{
			e1.printStackTrace();
			System.out.println("something "+e1.getMessage());

		}
		break;

		case 3:
			System.out.println("\n\n");
			System.out.println("enter id");
			id=console.nextInt();

			try{
				Employee emp1= empService.getemployee(id);

				System.out.println("id:"+emp1.getId());
				System.out.println("name:"+emp1.getName());
				System.out.println("salary:"+emp1.getSalary());
				System.out.println("doj is"+emp1.getDateofjoining());

				System.out.println("do you want to upadate name?(y/n)");
				char reply = console.next().charAt(0);
				if (reply=='y' ||reply== 'Y')
				{
					System.out.println("oldname=" +emp1.getName());
					System.out.println("provide new name");
					emp1.setName(console.next());
				}



				System.out.println("do you want to upadate salary?(y/n)");
				reply = console.next().charAt(0);
				if (reply=='y' ||reply== 'Y')
				{
					System.out.println("oldname=" +emp1.getSalary());
					System.out.println("provide new salary");
					emp1.setSalary(console.nextDouble());
				}

//				System.out.println("do you want to doj?(y/n)");
//				reply = console.next().charAt(0);
//				if (reply=='y' ||reply== 'Y')
//				{
//					System.out.println("olddoj=" +emp1.getDateofjoining());
//					System.out.println("provide new doj");
//					strDate=console.next();
//					arr = strDate.split("/");
//					dd = Integer.parseInt(arr[0]);
//					mm = Integer.parseInt(arr[1]);
//					yyyy= Integer.parseInt(arr[2]);
//
//					dateofjoining = Date(dd,mm, yyyy);
//					emp1.setDateofjoining(dateofjoining);
//				

				
				empService.UpdateEmployee(emp1);
				System.out.println("employee with"+emp1.getId()+"updatee suuccessfully");
				System.out.println("\n\n\n");
			}
			catch(EmployeeException e1)
			{
				e1.printStackTrace();
				System.out.println("something "+e1.getMessage());

			}



		







			break;
		case 4:System.out.println("\n\n");
		System.out.println("enter id");
		id=console.nextInt();

		try{
			empService.removeEmployee(id);

			System.out.println("employee with"+id+ "removed successfully");
		}
		catch(EmployeeException e1)
		{
			e1.printStackTrace();
			System.out.println("something "+e1.getMessage());

		}

		break;

		case 5:try{
			ArrayList<Employee> emps = empService.getEmployees();
			Iterator<Employee> it= emps.iterator();
			while(it.hasNext())
			{
				Employee emp = it.next();
				System.out.println("\n\n");
				System.out.println("id:"+emp.getId());
				System.out.println("name:"+emp.getName());
				System.out.println("salary:"+emp.getSalary());
  			System.out.println("doj:"+emp.getDateofjoining());
			}
			System.out.println("\n\n");
			console.next();
		}
		catch(EmployeeException e)
		{ e.printStackTrace();
		System.out.println("something went wrong");
		}
		break;

		case 6:

			System.exit(0);
		default:
			System.out.println("wrong input");
			break;
		}	
	}

	
}
