package com.capgemini.core.emsystem.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;




import com.capgemini.core.emsystem.beans.Employee;
import com.capgemini.core.emsystem.exception.EmployeeException;
import com.capgemini.core.emsystem.service.EmployeeServiceImpl;
import com.capgemini.core.emsystem.service.IEmployeeService;

public class EmployeeUserInterface
{
	//loose coupling
	IEmployeeService empService = new EmployeeServiceImpl();
	
	public void emsystemOperation()
	{
	Scanner console = new Scanner(System.in);
	
	
	int choice=0;
	System.out.println("1)add employee");
	System.out.println("2)get employee");
	System.out.println("3)update employee");
	System.out.println("4)remove employee");
	System.out.println("5)view all employee");
	System.out.println("6)exit application");
	
	System.out.println("enter your choice");
	
	choice= console.nextInt();
	switch(choice)
	{
	
	case 1:
		
		double Id=(Math.random()*1000);
		
		System.out.println("ENTER EMPLOYEE NAME");
		String name = console.next();
		
		System.out.println("enter salary");
		double salary = console.nextDouble();
		
		//instantiating n initializing employee object
		
		Employee employee = new Employee();
		
		employee.getId(Id);
		employee.setName(name);
		employee.setSalary(salary);
		//pass employee details(employee object) to service layer
		
		try {
			
			empService.addEmployee(employee);
			System.out.println("employee added succesfully");
		    } 
		catch (EmployeeException e)
		{
			
		e.printStackTrace();
			System.out.println("something went wrong while adding" +e.getMessage());
		}
		
	
		break;
	
	case 2:   System.out.println("\n\n");
	System.out.println("enter id");
	Id=console.nextInt();
	
	try{
	Employee emp1= empService.getemployee(Id);
	
	System.out.println("id:"+emp1.getId(Id));
	System.out.println("name:"+emp1.getName());
	System.out.println("salary:"+emp1.getSalary());
	
	System.out.println("\n\n\n");
	}
	catch(EmployeeException e1)
	{
		e1.printStackTrace();
	System.out.println("something "+e1.getMessage());
		
	}
		break;
	
	case 3:
		System.out.println("\n\n");
		System.out.println("enter id");
		Id=console.nextInt();
		
		try{
		Employee emp1= empService.getemployee(Id);
		
		System.out.println("id:"+emp1.getId(Id));
		System.out.println("name:"+emp1.getName());
		System.out.println("salary:"+emp1.getSalary());
		
		System.out.println("do you want to upadate name?(y/n)");
		char reply = console.next().charAt(0);
		if (reply=='y' ||reply== 'Y')
		{
			System.out.println("oldname=" +emp1.getName());
			System.out.println("provide new name");
			emp1.setName(console.next());
		}
		
		
		
		System.out.println("do you want to upadate salary?(y/n)");
		reply = console.next().charAt(0);
		if (reply=='y' ||reply== 'Y')
		{
			System.out.println("oldname=" +emp1.getSalary());
			System.out.println("provide new salary");
			emp1.setSalary(console.nextDouble());
		}
		
		empService.UpdateEmployee(emp1);
		System.out.println("employee with"+emp1.getId(Id)+"updatee suuccessfully");
		System.out.println("\n\n\n");
		}
		catch(EmployeeException e1)
		{
			e1.printStackTrace();
		System.out.println("something "+e1.getMessage());
			
		}
		
		
		
		
		
		
		
		
		
		
		break;
	case 4:System.out.println("\n\n");
	System.out.println("enter id");
	Id=console.nextInt();
	
	try{
	empService.removeEmployee(Id);
	
	System.out.println("employee with"+Id+ "removed successfully");
	}
	catch(EmployeeException e1)
	{
		e1.printStackTrace();
	System.out.println("something "+e1.getMessage());
		
	}
		
		break;
	
	case 5:try{
		ArrayList<Employee> emps = empService.getEmployees();
		Iterator<Employee> it= emps.iterator();
		while(it.hasNext())
			{
			Employee emp = it.next();
			System.out.println("\n\n");
			System.out.println("id:"+emp.getId(Id));
			System.out.println("name:"+emp.getName());
			System.out.println("salary:"+emp.getSalary());
			}
		System.out.println("\n\n");
		console.next();
		}
	catch(EmployeeException e)
	{ e.printStackTrace();
	System.out.println("something went wrong");
	}
		break;
	
	case 6:
		
		System.exit(0);
		default:
			System.out.println("wrong input");
			break;
	}	
}	
}
