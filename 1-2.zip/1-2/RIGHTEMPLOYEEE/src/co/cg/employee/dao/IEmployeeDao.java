package co.cg.employee.dao;

public class IEmployeeDao {

}
