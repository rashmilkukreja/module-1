package co.cg.employee.ui;

import java.util.Scanner;

public class MyTest {
	public static void main(String[] args)
	{
		
		

		int choice =0;

do{
	printDetail();
	Scanner scr=new Scanner(System.in);
	System.out.println("enter choice");
	choice=scr.nextInt();
	
	switch(choice)
	{
	case 1:
		break;
	case 2:
		break;
	case 3:
		break;
	case 4:
		break;
	case 5: 
		System.exit(0);
		break;
	
	
	
	
	
	
	
	
	
	}
}while(choice!=4);
	}
	public static void printDetail(){
		System.out.println("*******************************************************************************");
		System.out.println("1) ADD product");
		System.out.println("2) show all products");
		System.out.println("3) search product");
		System.out.println("4) remove product");
		System.out.println("5) exit");
		System.out.println("******************************************************************************");
		
		
		
	}	
}