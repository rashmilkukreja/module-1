package co.cg.pms.ui;


import java.util.List;
import java.util.Scanner;



import com.cg.pms.service.IProductService;
import com.cg.pms.service.ProductServiceImpl;

import co.cg.pms.dto.Product;
import co.cg.pms.exception.exception;

public class MyTest
{
public static void main(String[] args)
{
	
	

	int choice =0;
	//run time polymorphism
	IProductService prodservice=new ProductServiceImpl();
	
	do{
		printDetail();
		Scanner scr=new Scanner(System.in);
		System.out.println("enter choice");
		choice=scr.nextInt();
		
		switch(choice)
		{
		case 1:  //add 
			int msg=0;
			String patt="[A-Z][a-z]{2,19}";
//			System.out.println("enter product id");
//			int prodId=scr.nextInt();
			System.out.println("enter product name");
			String prodName=scr.next();
			try {
				
				ProductServiceImpl.validateName(prodName,patt); //auto
			} catch (exception e1) {
				// TODO Auto-generated catch block
//				e1.printStackTrace();
				System.out.println(e1.getMessage());
				break;
			}
			System.out.println("enter product price");
			int prodPrice=scr.nextInt();
			System.out.println("enter product description");
			String prodDes=scr.next();
			
			Product prod=new Product();
//			prod.setProductId(prodId);
			prod.setProductName(prodName);
			prod.setProductPrice(prodPrice);
			prod.setProductDes(prodDes);
			//call service layer
			
			
			try {
				msg = prodservice.addProduct(prod);
			} catch (exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
			
			if(msg==0){
				System.out.println("data not inserted" );
			}
			else{System.out.println("data inserted with id is"+msg);
			    }
			break;
		case 2: //show all
			List<Product> myProd=null;
			try {
				myProd = prodservice.showall();
			} catch (exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
			for (Product product : myProd) 
			{
				System.out.println("id is=" +product.getProductId());
				System.out.println("name is=" +product.getProductName());
				System.out.println("price is=" +product.getProductPrice());
				System.out.println("description is=" +product.getProductDes());
				System.out.println("\n");
			}
			
			break;
		case 3: //search
			System.out.println("enter product id");
			int id=scr.nextInt();
			Product mySearchProd=null;
			try {
				mySearchProd = prodservice.searchProduct(id);
			System.out.println("id is=" +mySearchProd.getProductId());
			System.out.println("name is=" +mySearchProd.getProductName());
			System.out.println("price is=" +mySearchProd.getProductPrice());
			System.out.println("description is=" +mySearchProd.getProductDes());
			System.out.println("\n");
			
			} catch (exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
			
			
			break;
		case 4: //remove
			
			System.out.println("\n\n");
			System.out.println("enter id");
			id=scr.nextInt();
			Product myRemove=null;

			try{
				myRemove=prodservice.removeProduct(id);

				System.out.println("employee with"+id+ "removed successfully");
			}
			catch(exception e)
			{
				e.printStackTrace();
				System.out.println("something "+e.getMessage());

			}
			break;
		case 5: 
			System.exit(0);
			break;
			
		
		
		
		
		
		
		
		
	}
}while(choice!=5);
}
	
	public static void printDetail(){
	System.out.println("*******************************************************************************");
	System.out.println("1) ADD product");
	System.out.println("2) show all products");
	System.out.println("3) search product");
	System.out.println("4) remove product");
	System.out.println("5) exit");
	System.out.println("******************************************************************************");
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
}