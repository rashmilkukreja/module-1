package co.cg.pms.dao;

import java.util.List;

import co.cg.pms.dto.Product;
import co.cg.pms.exception.exception;

public interface IProductDao
{
	public int addProduct(Product pro) throws exception;
	public List<Product> showall() throws exception;
	public Product searchProduct(int prodId) throws exception;
	public Product removeProduct(int prodId)  throws exception;
	
	
	
}
