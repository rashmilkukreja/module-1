package co.cg.pms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.pms.util.DbUtil;

import co.cg.pms.dto.Product;
import co.cg.pms.exception.exception;

public class ProductDaoImpl implements IProductDao
{ private static final Logger myLog=Logger.getLogger(DbUtil.class);
		static Connection con=null;
static PreparedStatement pstm=null;

	@Override
	public int addProduct(Product pro) throws exception  {
		int status=0;
		int idReturn=0;
		con=DbUtil.getConnection();
		int prodId=getProductId();
		String query="INSERT INTO PRODUCTDB VALUES(?,?,?,?)";
		
			try {
				pstm=con.prepareStatement(query);
				pstm.setInt(1,prodId);
				pstm.setString(2,pro.getProductName());
				pstm.setDouble(3, pro.getProductPrice());
				pstm.setString(4,pro.getProductDes());
				
				
			status=pstm.executeUpdate();
			if (status==1)
			{
				idReturn=prodId;
				myLog.info("data inserted..."+prodId);
			}
			}
			
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new exception("problem in insert");
			}
			finally{
				try{
				pstm.close();
				con.close();
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			} 
			
	return idReturn;

}
	
	@Override
	public List<Product> showall() throws exception {
		List<Product> myList=new ArrayList<Product>();
		
		con=DbUtil.getConnection();
		String queryTwo="SELECT prod_id,prod_name,prod_price,prod_des from ProductDB";
		try {
			pstm=con.prepareStatement(queryTwo);
			ResultSet res=pstm.executeQuery();
			
			while(res.next()){
				Product pr=new Product();
				pr.setProductId(res.getInt("prod_id"));
				pr.setProductName(res.getString("prod_name"));
				pr.setProductPrice(res.getDouble("prod_price"));
				pr.setProductDes(res.getString("prod_des"));
				
				myList.add(pr);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try{
			pstm.close();
			con.close();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new exception("problem in show");
		}
		}
		return myList;
	}

	@Override
	public Product searchProduct(int prodId) throws exception {
	Product pSearch=null;
		try{
		con=DbUtil.getConnection();
		String queryThree="SELECT * FROM ProductDB WHERE prod_id=?";
		pstm=con.prepareStatement(queryThree);
		pstm.setInt(1, prodId);
		ResultSet resOne=pstm.executeQuery();
		
		
		while(resOne.next()){
			pSearch=new Product();
			pSearch.setProductId(resOne.getInt("prod_id"));
			pSearch.setProductName(resOne.getString("prod_name"));
			pSearch.setProductPrice(resOne.getDouble("prod_price"));
			pSearch.setProductDes(resOne.getString("prod_des"));
		
		
		
		
		
		}}
		catch(Exception e)
		{e.printStackTrace();
		throw new exception("problem in show");
			}
		
	
		
	finally{
		try{
		pstm.close();
		con.close();}
		catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		throw new exception("problem in search");
	}
	}
	return pSearch;
	}


	@Override
	public Product removeProduct(int prodId) throws exception {
	
	try{
	con=DbUtil.getConnection();
	String queryFour="DELETE FROM ProductDB WHERE PROD_ID=?";
	pstm=con.prepareStatement(queryFour);
	pstm.setInt(1, prodId);
	ResultSet resOne=pstm.executeQuery();
	
	
	
	
	
}
	catch(Exception e)
	{e.printStackTrace();
	throw new exception("problem in remove");
		}
	

	
finally{
	try{
	pstm.close();
	con.close();}
	catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	throw new exception("problem in remove.........");
}
}
	return null;

}
		

	
	public static int getProductId() throws exception
	{ int productId=0;
		try {
			con=DbUtil.getConnection();
			String queryFive="SELECT prod_id_seq.nextval from DUAL";
			pstm=con.prepareStatement(queryFive);
			ResultSet resTwo=pstm.executeQuery();
			while(resTwo.next()){
				
				productId=resTwo.getInt(1);
				
			}
			
		} catch (exception | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new exception("problem in Getting Id");
		}
		return productId;
		
	}
	
	
	
	
	
	
	
	
	
	
}
