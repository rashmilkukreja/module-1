package co.cg.pms.exception;

public class exception extends Exception {

	public exception() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public exception(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

	

	
	
	

}
