package com.cg.pms.junitTest;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import co.cg.pms.dao.ProductDaoImpl;
import co.cg.pms.dto.Product;
import co.cg.pms.exception.exception;


public class ProductDaoTest {
	
	Product prod=null;
ProductDaoImpl prodDao=null;
@Before
public void callBefore(){
 prod=new Product();
prod.setProductName("Aaaa");
prod.setProductPrice(1234);
prod.setProductDes("hdhfd");
prodDao=new ProductDaoImpl();
	}

@Test
public void myTestCase() throws exception{
assertEquals(1018,prodDao.addProduct(prod));
	}
@After
public void callAfter(){
}

}

