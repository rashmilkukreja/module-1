package com.cg.pms.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

import co.cg.pms.exception.exception;

public class DbUtil
{
	static	Connection conn=null;
	private static final Logger mylogger=Logger.getLogger(DbUtil.class);
	
	public static Connection getConnection() throws exception{
	
		FileInputStream fileRead;
		try {
			fileRead = new FileInputStream("oracle.properties");
		
		Properties pros=new Properties();
		pros.load(fileRead);
		
		String driver=pros.getProperty("oracle.driver");
		String url=pros.getProperty("oracle.url");
		String uname=pros.getProperty("oracle.username");
		String upass=pros.getProperty("oracle.password");
		
		Class.forName(driver);
		
		conn=DriverManager.getConnection(url, uname, upass);
		mylogger.info("connection established....");
		
		} catch (IOException | SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			mylogger.info("connection not establish.......");
		}
	
	return conn;
		
	
	
	
	
	
	
	
	
	
	
	
	}
	}
