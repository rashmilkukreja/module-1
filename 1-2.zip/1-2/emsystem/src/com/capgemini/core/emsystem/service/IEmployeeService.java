package com.capgemini.core.emsystem.service;

import java.util.ArrayList;

import com.capgemini.core.emsystem.beans.Employee;
import com.capgemini.core.emsystem.exception.EmployeeException;

public interface IEmployeeService
{

	
	
	
	
	public void addEmployee(Employee employee) throws EmployeeException;
	public  Employee getemployee(int id) throws EmployeeException;
	public void UpdateEmployee(Employee employee) throws EmployeeException;
	public void removeEmployee(int id) throws EmployeeException;
	public ArrayList<Employee> getEmployees() throws EmployeeException;
	

	
	
	
	
}
