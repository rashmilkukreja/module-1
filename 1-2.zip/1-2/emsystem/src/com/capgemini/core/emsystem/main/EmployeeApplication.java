package com.capgemini.core.emsystem.main;

import com.capgemini.core.emsystem.ui.EmployeeUserInterface;

public class EmployeeApplication {

	public static void main(String[] args) 
	{
		EmployeeUserInterface ui = new EmployeeUserInterface();
		while(true){
			ui.emsystemOperation();
		}
	}

}
