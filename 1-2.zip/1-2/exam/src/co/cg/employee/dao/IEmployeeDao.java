package co.cg.employee.dao;

public interface IEmployeeDao {

}
