package co.cg.employee.dao;

public class ContactBookDaoImpl {

}
