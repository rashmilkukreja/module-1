package co.cg.employee.dto;

public class employee {

}
