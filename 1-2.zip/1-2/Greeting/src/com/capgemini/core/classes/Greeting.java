package com.capgemini.core.classes;

public class Greeting {

	public static void main(String[] args) {
		//autocomplete
		//hot compilation
		//intelegence
		System.out.println("hello world");
		
	}

}
