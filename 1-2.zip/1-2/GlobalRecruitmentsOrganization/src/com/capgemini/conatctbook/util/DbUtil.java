package com.capgemini.conatctbook.util;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.capgemini.contactbook.exception.*;

public class DbUtil 
{
	public static Connection conn=null;
	private static final Logger mylogger = Logger.getLogger(DbUtil.class);
public static Connection getConnection() throws ContactBookException
	{
		FileInputStream fileRead;
		try {
			fileRead = new FileInputStream("oracle.properties");
			Properties pros =new Properties();
			pros.load(fileRead);	//Load Properties File
			
			String driver=pros.getProperty("oracle.driver");
			String url=pros.getProperty("oracle.url");
			String uname=pros.getProperty("oracle.username");
			String upass=pros.getProperty("oracle.password");
			
//Load The Driver
			Class.forName(driver);
//Making Connection
			conn=DriverManager.getConnection(url, uname, upass);
			 mylogger.info("Connection Established...");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			mylogger.info("Connection not Established......."+e);
//			throw new ContactBookException("Connection Not Established......");
		}
		return conn;
	}

}
