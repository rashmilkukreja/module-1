package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.conatctbook.util.DbUtil;
import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;




public class ContactBookDaoImpl implements ContactBookDao 
{
	private static final Logger myLog=Logger.getLogger(ContactBookDaoImpl.class);
	static Connection conn=null;
	static PreparedStatement pstm=null;
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException 
	{
		conn=DbUtil.getConnection();
		int enquiryId=getId();
		int status=0;
		String query="INSERT INTO enquiry VALUES(?,?,?,?,?,?)";
		try{
			pstm=conn.prepareStatement(query);
			pstm.setInt(1,enquiryId);
			pstm.setString(2,enqry.getfName());
			pstm.setString(3,enqry.getlName());
			pstm.setString(4,enqry.getContactNo());
			pstm.setString(5,enqry.getpDomain());
			pstm.setString(6,enqry.getpLocation());
			status=pstm.executeUpdate();
			myLog.info("Query Executed and Data Inserted");
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			try {
				throw new ContactBookException("Problem in Insert");
			} catch (ContactBookException e1) 
			{
				e1.printStackTrace();
			}
		}
		finally{
			try{
				pstm.close();
				conn.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		return enquiryId;
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException 
	{
		 EnquiryBean eSearch=null;
		try {
			conn=DbUtil.getConnection();
			String querythree="SELECT enqryId,firstName,lastName,contactNo,domain,city FROM enquiry WHERE enqryId=?";
			pstm=conn.prepareStatement(querythree);
			pstm.setInt(1,EnquiryID);
			ResultSet resOne=pstm.executeQuery();
			eSearch=new EnquiryBean();
			while(resOne.next())
			{
			eSearch.setEnqryId(resOne.getInt("enqryId"));
			eSearch.setfName(resOne.getString("firstName"));
			eSearch.setlName(resOne.getString("lastName"));
			eSearch.setContactNo(resOne.getString("contactNo"));
			eSearch.setpDomain(resOne.getString("domain"));
			eSearch.setpLocation(resOne.getString("city"));
			}
			
		} 	
		catch (ContactBookException | SQLException e) 
		{
			e.printStackTrace();
			throw new ContactBookException("Problem in Search...");
		}
		finally
		{
			try{
				pstm.close();
				conn.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		return eSearch;
	}
	public static int getId() throws ContactBookException
	{
		int enqryId=0;
	try {
		conn=DbUtil.getConnection();
		String queryFive="SELECT enquiries.nextval FROM DUAL";
		pstm=conn.prepareStatement(queryFive);
		ResultSet resTwo=pstm.executeQuery();
		while(resTwo.next())
		{
			enqryId=resTwo.getInt(1);
		}
	    } 
	catch (ContactBookException | SQLException e) 
	    {
		// TODO Auto-generated catch block
		e.printStackTrace();
		throw new ContactBookException("Problem in Getting Id");
	    }
		return enqryId;
			
	}
	
}
