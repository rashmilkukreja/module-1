package com.capgemini.contactbook.service;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;

public class ContactBookServiceImpl implements ContactBookService 
{
	ContactBookDao cbdDao=new ContactBookDaoImpl();
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException 
	{
		
		return cbdDao.addEnquiry(enqry);
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException 
	{
		return cbdDao.getEnquiryDetails(EnquiryID);
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry)
			throws ContactBookException 
	{
		//ContactBookServiceImpl valid= new ContactBookServiceImpl();
		//valid.getEnquiryDetails(enqry.getEnqryId());
		if(enqry.getEnqryId()!='\0')
		return true;
		else	
		return false;
	}

	

}
