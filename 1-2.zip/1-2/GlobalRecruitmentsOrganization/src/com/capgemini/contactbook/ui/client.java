package com.capgemini.contactbook.ui;

import java.util.List;
import java.util.Scanner;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;


public class client {

	public static void main(String[] args) throws ContactBookException 
	{
		int choice=0,msg=0;
		
		EnquiryBean mysearchclient=null;
		ContactBookService cbs=new ContactBookServiceImpl();
		do{
		//User Display Block
		System.out.println("*************Global Recruitments*****************");
		System.out.println("Choose an Operation");
		System.out.println("1.Enter Enquiry Details");
		System.out.println("2.View Enquiry Details on Id");
		System.out.println("0.Exit");
		System.out.println("*************************************************");
		
		Scanner object=new Scanner(System.in);
		System.out.print("Please enter a choice:");
		choice=object.nextInt();
		
		switch(choice)
		{
		case 0://Exit
			System.exit(0);
			break;
		case 1://Enquiry Details
			System.out.print("Enter First Name:");
			String fName=object.next();
			System.out.print("Enter Last Name:");
			String lName=object.next();
			System.out.print("Enter Contact Number:");
			String contactNo=object.next();
			System.out.print("Enter Preferred Domain:");
			String pDomain=object.next();
			System.out.print("Enter Preferred Location");
			String pLocation=object.next();
			
			EnquiryBean enqry1=new EnquiryBean();
			enqry1.setfName(fName);
			enqry1.setlName(lName);
			enqry1.setContactNo(contactNo);
			enqry1.setpDomain(pDomain);
			enqry1.setpLocation(pLocation);
			
			msg=cbs.addEnquiry(enqry1);
			if(msg==0)
			{
			System.out.println("Data not Inserted");
			}
			else
			{
			System.out.println("Data Inserted Enquiry Id is:"+msg);
			}
			break;
			
		case 2:
			System.out.println("Enter Enquiry Id.");
			int id=object.nextInt();
			try{
			mysearchclient=cbs.getEnquiryDetails(id);
			}
			catch(ContactBookException e)
			{
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
			if(cbs.isValidEnquiry(mysearchclient))
			{
			System.out.println("Id:"+mysearchclient.getEnqryId());
			System.out.println("First Name:"+mysearchclient.getfName());
			System.out.println("Last Name:"+mysearchclient.getlName());
			System.out.println("Contact No:"+mysearchclient.getContactNo());
			System.out.println("Preferred Domain:"+mysearchclient.getpDomain());
			System.out.println("Preferred Location:"+mysearchclient.getpLocation());
			}
			else
			{
			System.out.println("Sorry no Details Found");	
			}
			break;
			default:
			System.out.println("Wrong Input");
			break;
		}
		}while(choice!=3);

	}
	

}
