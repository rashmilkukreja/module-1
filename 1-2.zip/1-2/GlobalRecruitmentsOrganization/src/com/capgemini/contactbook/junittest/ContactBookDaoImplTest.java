package com.capgemini.contactbook.junittest;

public class ContactBookDaoImplTest 
{

}
