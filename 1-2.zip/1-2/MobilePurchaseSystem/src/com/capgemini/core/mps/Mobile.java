package com.capgemini.core.mps;

public class Mobile
{
private int mobileid;
private String mobilename;
private int price;
private String quantity;

public Mobile(int mobileid, String mobilename, int price, String quantity) {
	super();
	this.mobileid = mobileid;
	this.mobilename = mobilename;
	this.price = price;
	this.quantity = quantity;
}
public Mobile() {
	super();
	// TODO Auto-generated constructor stub
}
public int getMobileid() {
	return mobileid;
}
public void setMobileid(int mobileid) {
	this.mobileid = mobileid;
}
public String getMobilename() {
	return mobilename;
}
public void setMobilename(String mobilename) {
	this.mobilename = mobilename;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public String getQuantity() {
	return quantity;
}
public void setQuantity(String prodDes) {
	this.quantity = prodDes;
}
@Override
public String toString() {
	return "Mobile [mobileid=" + mobileid + ", mobilename=" + mobilename
			+ ", price=" + price + ", quantity=" + quantity + "]";
}

}
