package com.capgemini.core.mps;

import java.sql.Date;

public class PurchaseDetails 
{
private int purchaseid;
private String cname;
private String mailid;
private double phoneno;
private Date purchasedate;
public String mobileid;
@Override
public String toString() {
	return "PurchaseDetails [purchaseid=" + purchaseid + ", cname=" + cname
			+ ", mailid=" + mailid + ", phoneno=" + phoneno + ", purchasedate="
			+ purchasedate + ", mobileid=" + mobileid + "]";
}
public int getPurchaseid() {
	return purchaseid;
}
public void setPurchaseid(int purchaseid) {
	this.purchaseid = purchaseid;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getMailid() {
	return mailid;
}
public void setMailid(String mailid) {
	this.mailid = mailid;
}
public double getPhoneno() {
	return phoneno;
}
public void setPhoneno(double phoneno) {
	this.phoneno = phoneno;
}
public Date getPurchasedate() {
	return purchasedate;
}
public void setPurchasedate(Date purchasedate) {
	this.purchasedate = purchasedate;
}
public String getMobileid() {
	return mobileid;
}
public void setMobileid(String mobileid) {
	this.mobileid = mobileid;
}
public PurchaseDetails() {
	super();
	// TODO Auto-generated constructor stub
}
public PurchaseDetails(int purchaseid, String cname, String mailid,
		double phoneno, Date purchasedate, String mobileid) {
	super();
	this.purchaseid = purchaseid;
	this.cname = cname;
	this.mailid = mailid;
	this.phoneno = phoneno;
	this.purchasedate = purchasedate;
	this.mobileid = mobileid;
}
	
	
	
	
	
	
	
	
	
	
	
	
}
