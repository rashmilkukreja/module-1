package com.capgemini.core.Service;

import java.util.List;

import com.capgemini.core.mps.Mobile;
import com.capgemini.core.mps.PurchaseDetails;



public interface IMobileService
{
public  int addData(PurchaseDetails purdet) ;
	
	public abstract List<Mobile> showAllData();
	
	public abstract void removeData(int mobileId);
	
	public abstract void updateMobile(String mobileId);
	
	public abstract List<Mobile> search(double min,double max);

}


