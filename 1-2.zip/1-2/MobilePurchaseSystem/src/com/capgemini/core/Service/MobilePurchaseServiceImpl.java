package com.capgemini.core.Service;

import java.util.List;



import java.util.regex.Pattern;




import com.capgemini.core.Exception.exception;
import com.capgemini.core.dao.IMobileDao;
import com.capgemini.core.dao.MobileDaoImpl;
import com.capgemini.core.mps.Mobile;
import com.capgemini.core.mps.PurchaseDetails;

public class MobilePurchaseServiceImpl implements IMobileService {
	IMobileDao mobDao = new MobileDaoImpl();

	@Override
	public int addData(PurchaseDetails purdet) {
		// TODO Auto-generated method stub
		return mobDao.addProduct(purdet);
	}

	@Override
	public List<Mobile> showAllData() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeData(int mobileId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateMobile(String mobileId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Mobile> search(double min, double max) {
		// TODO Auto-generated method stub
		return null;
	}

	public static boolean validateName(String prodName,String prodPattern) throws exception
	{ 
	boolean validation=Pattern.matches(prodPattern, prodName);
	if(!validation){
		throw new exception("first letter shud b CAP,min 3,max20");
	}
	return validation;
		}
}
