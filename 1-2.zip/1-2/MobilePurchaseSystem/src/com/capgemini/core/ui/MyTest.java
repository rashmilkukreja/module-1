package com.capgemini.core.ui;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

import com.capgemini.core.Exception.exception;
import com.capgemini.core.Service.IMobileService;
import com.capgemini.core.Service.MobilePurchaseServiceImpl;
import com.capgemini.core.mps.Mobile;
import com.capgemini.core.mps.PurchaseDetails;




public class MyTest {

	public static void main(String[] args) {
		IMobileService prodservice=new MobilePurchaseServiceImpl();
		
				
		int choice=0;
	do{	
		printDetails();
	
	Scanner scr=new Scanner(System.in);
	System.out.println("enter choice");
	choice=scr.nextInt();
	
	switch(choice)
	{
	case 1:  //add 
		int msg=0;
		String patt="[A-Z][a-z]{2,19}";
//		System.out.println("enter product id");
//		int prodId=scr.nextInt();
		System.out.println("enter employee name");
		String empName=scr.next();
		try {
			
			 MobilePurchaseServiceImpl.validateName(empName,patt); //auto
		} catch (exception e1) {
//			 TODO Auto-generated catch block
			e1.printStackTrace();
			System.out.println(e1.getMessage());
			break;
		}
		System.out.println("enter product price");
		int prodPrice=scr.nextInt();
		System.out.println("enter product description");
		String prodDes=scr.next();
		
		Mobile mob=new Mobile();
//		prod.setProductId(prodId);
		mob.setMobilename(empName);
		mob.setPrice(prodPrice);
		mob.setQuantity(prodDes);
		//call service layer
		
		
		try {
			msg = prodservice.addProduct(prod);
		} catch (exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
		if(msg==0){
			System.out.println("data not inserted" );
		}
		else{System.out.println("data inserted with id is"+msg);
		    }
		break;
	case 2: //show all
//		List<Product> myProd=null;
//		try {
//			myProd = prodservice.showAllData();
//		} catch (exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			System.out.println(e.getMessage());
//		}
//		for (Product product : myProd) 
//		{
//			System.out.println("id is=" +product.getProductId());
//			System.out.println("name is=" +product.getProductName());
//			System.out.println("price is=" +product.getProductPrice());
//			System.out.println("description is=" +product.getProductDes());
//			System.out.println("\n");
//		}
		
		break;
		
	
	case 3: break;
	
	case 4: break;
	case 5: break;
	case 6: 
	System.exit(0);

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}
	}while(choice!=5);
		}
public static void printDetails(){
	System.out.println("***************************************");
	System.out.println("`1)insert customer");
	System.out.println("2)update customer");
	System.out.println("3)view all mobile");
	System.out.println("4)delete mobile details");
	System.out.println("5)search");
	System.out.println("6)exit");
	System.out.println("*************************************************");}
}
