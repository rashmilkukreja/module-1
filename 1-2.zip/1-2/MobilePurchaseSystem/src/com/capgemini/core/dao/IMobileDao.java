package com.capgemini.core.dao;

import java.util.List;

import com.capgemini.core.mps.Mobile;
import com.capgemini.core.mps.PurchaseDetails;

public interface IMobileDao {


	
	public abstract List<Mobile> showAllData();
	
	public abstract void removeData(int mobileId);
	
	public abstract void updateMobile(String mobileId);
	
	public abstract List<Mobile> search(double min,double max);

	public int addProduct(PurchaseDetails purdet);

	int addData(PurchaseDetails purdet);

	

}
