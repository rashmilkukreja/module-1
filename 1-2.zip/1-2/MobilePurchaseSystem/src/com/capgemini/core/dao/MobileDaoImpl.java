package com.capgemini.core.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.core.Exception.exception;
import com.capgemini.core.mps.Mobile;
import com.capgemini.core.mps.PurchaseDetails;




public class MobileDaoImpl implements IMobileDao
{
	private static final Logger myLog=Logger.getLogger(com.capgemini.core.util.DbUtil.class);
	static Connection con=null;
static PreparedStatement pstm=null;

	@Override
	public int addData(PurchaseDetails purdet) {
		int status=0;
		int idReturn=0;
		try {
			con=com.capgemini.core.util.DbUtil.getConnection();
		} catch (exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int prodId=getId();
		String query="INSERT INTO MobileDB VALUES(?,?,?,?)";
		
			try {
				pstm=con.prepareStatement(query);
				pstm.setInt(1,prodId);
				pstm.setString(2,purdet.getCname());
			
				
				
				
				
			status=pstm.executeUpdate();
			if (status==1)
			{
				idReturn=prodId;
				myLog.info("data inserted..."+prodId);
			}
			}
			
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
//				throw new exception("problem in insert");
			}
			finally{
				try{
				pstm.close();
				con.close();
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			} 
			
	return idReturn;

}
	private int getId() {
		// TODO Auto-generated method stub
		return 0;
	}
	

	@Override
	public List<Mobile> showAllData() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeData(int mobileId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateMobile(String mobileId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Mobile> search(double min, double max) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public int addProduct(PurchaseDetails purdet) {
		// TODO Auto-generated method stub
		return 0;
	}

}
