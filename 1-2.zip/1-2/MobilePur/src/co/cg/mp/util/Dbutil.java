package co.cg.mp.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.mps.exception.exception;



public class Dbutil {
	 public static Connection conn=null;
     public static Connection getConnection() throws exception
     {
                     
      FileInputStream fileRead;
     try {
                     fileRead = new FileInputStream("oracle.properties");
                     Properties emps = new Properties();
                     emps.load(fileRead);
                     String driver=emps.getProperty("oracle.driver");
                     String url=emps.getProperty("oracle.url");
                     String uname=emps.getProperty("oracle.username");
                     String upass=emps.getProperty("oracle.password");
                     Class.forName(driver);
                     conn=DriverManager.getConnection(url,uname,upass);
                     System.out.println("Connection established...");
                     
     } catch (IOException | ClassNotFoundException | SQLException e) {

                     e.printStackTrace();
                     System.out.println("Connection not established...");
                     //throw new EmployeeException("Connection not established");
     }
     return conn;
     
      }

}
