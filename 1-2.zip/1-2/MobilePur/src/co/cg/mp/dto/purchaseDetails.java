package co.cg.mp.dto;

import java.sql.Date;

public class purchaseDetails {
	private int purchaseid;
	private String cname;
	private String mailid;
	private String phoneno;
	private Date purchasedate;
	private int mobileid;
	public purchaseDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public purchaseDetails(int purchaseid, String cname, String mailid,
			String phoneno, Date purchasedate, int mobileid) {
		super();
		this.purchaseid = purchaseid;
		this.cname = cname;
		this.mailid = mailid;
		this.phoneno = phoneno;
		this.purchasedate = purchasedate;
		this.mobileid = mobileid;
	}
	public int getPurchaseid() {
		return purchaseid;
	}
	public void setPurchaseid(int purchaseid) {
		this.purchaseid = purchaseid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String pNo) {
		this.phoneno = pNo;
	}
	public Date getPurchasedate() {
		return purchasedate;
	}
	public void setPurchasedate(Date purchasedate) {
		this.purchasedate = purchasedate;
	}
	public int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	@Override
	public String toString() {
		return "purchaseDetails [purchaseid=" + purchaseid + ", cname=" + cname
				+ ", mailid=" + mailid + ", phoneno=" + phoneno
				+ ", purchasedate=" + purchasedate + ", mobileid=" + mobileid
				+ "]";
	}
	public Mobiles getMobile() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setMobileid(Mobiles mobile) {
		// TODO Auto-generated method stub
		
	}
	
	

}
