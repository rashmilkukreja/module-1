package co.cg.mp.dto;

public class Mobiles {
	private static int mobileid;
	private String name;
	private int price;
	private int quantity;
	public Mobiles(int mobileid, String name, int price, int quantity) {
		super();
		this.mobileid = mobileid;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}
	public Mobiles() {
		super();
		// TODO Auto-generated constructor stub
	}
	public static int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Mobiles [mobileid=" + mobileid + ", name=" + name + ", price="
				+ price + ", quantity=" + quantity + "]";
	}
	

}
