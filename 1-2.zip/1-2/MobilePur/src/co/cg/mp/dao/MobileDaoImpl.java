package co.cg.mp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;






import com.cg.mps.exception.exception;

import co.cg.mp.dto.Mobiles;
import co.cg.mp.dto.purchaseDetails;
import co.cg.mp.util.Dbutil;

public class MobileDaoImpl implements IMobileDao {
	 Connection conn=null;
     PreparedStatement pstm=null;
     

     

	@Override
	public int addData(purchaseDetails purdet) throws exception {
		int status=0;
        conn=Dbutil.getConnection();
        String query="Insert into purchasedetails values(?,?,?,?,?,?)";
        try {
        	Mobiles mobile = new Mobiles();
        	int pId=getPurchaseid();
        	
                        pstm=conn.prepareStatement(query);
                        
                        pstm.setInt(1,purdet.getPurchaseid());
                        pstm.setString(2, purdet.getCname());
                        pstm.setString(3, purdet.getMailid());
                        pstm.setString(4, purdet.getPhoneno());
                        pstm.setDate(5,purdet.getPurchasedate());
                         pstm.setInt(6,Mobiles.getMobileid());
                        status = pstm.executeUpdate();
                        
        } catch (SQLException e) {
                        
                        e.printStackTrace();
        }
        finally
        {
                        try {
                                        pstm.close();
                                        conn.close();
                        } catch (SQLException e) {
                                        e.printStackTrace();
                                        throw new exception("Problem in insert..");
                        }
                        
        }
        
        
return status;
	}

	private int getPurchaseid()  {
		int pId=0;
		try{
		conn=Dbutil.getConnection();
        String query="select pd_id_seq.nextval from dual";
        pstm=conn.prepareStatement(query);
        ResultSet restwo = pstm.executeQuery();
        while(restwo.next())
        {pId=restwo.getInt(1);}
	}
		catch(exception | SQLException e)
		{
			e.printStackTrace();}
		return pId;
		}

	@Override
	public List<Mobiles> showAllData() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeData(int mobileId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateMobile(int mobileId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Mobiles> search(double min, double max) {
		// TODO Auto-generated method stub
		return null;
	}

	
	

}
