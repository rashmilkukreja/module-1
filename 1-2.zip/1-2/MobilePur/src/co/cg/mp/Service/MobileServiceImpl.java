package co.cg.mp.Service;





import java.util.List;
import java.util.regex.Pattern;

import com.cg.mps.exception.exception;

import co.cg.mp.dao.IMobileDao;
import co.cg.mp.dao.MobileDaoImpl;
import co.cg.mp.dto.Mobiles;
import co.cg.mp.dto.purchaseDetails;

public class MobileServiceImpl implements IMobileService {
	 IMobileDao mobDao = new MobileDaoImpl();
	@Override
	public int addData(purchaseDetails purdet)throws exception {
		// TODO Auto-generated method stub
		  return mobDao.addData(purdet);
	}

	@Override
	public List<Mobiles> showAllData() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeData(int mobileId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateMobile(int mobileId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Mobiles> search(double min, double max) {
		// TODO Auto-generated method stub
		return null;
	}

	public static boolean validateName(String cname,String pattern) throws exception
	{ 
	boolean validation=Pattern.matches(pattern, cname);
	if(!validation){
		throw new exception("first letter shud b CAP,min 3,max20");
	}
	return validation;
		}


}
