package co.cg.mp.Service;

import java.util.List;

import com.cg.mps.exception.exception;

import co.cg.mp.dto.Mobiles;
import co.cg.mp.dto.purchaseDetails;

public interface IMobileService {
	
public int addData(purchaseDetails purdet)throws exception;
	
	public List<Mobiles> showAllData();
	
	public void removeData(int mobileId);
	
	public void updateMobile(int mobileId);
	
	public List<Mobiles> search(double min,double max);
}
