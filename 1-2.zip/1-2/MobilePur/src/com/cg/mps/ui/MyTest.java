package com.cg.mps.ui;

import java.util.Calendar;
import java.util.Scanner;
import java.util.regex.Pattern;




import com.cg.mps.exception.exception;

import co.cg.mp.Service.IMobileService;
import co.cg.mp.Service.MobileServiceImpl;
import co.cg.mp.dto.Mobiles;
import co.cg.mp.dto.purchaseDetails;

public class MyTest {
	
	
	

		public static void main(String[] args)
		{
			java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());
			
			IMobileService mobService=new MobileServiceImpl();

			int choice =0;

	do{
		printDetail();
		Scanner scr=new Scanner(System.in);
		System.out.println("enter choice");
		choice=scr.nextInt();
		
		switch(choice)
		{
		case 1:
            int msg = 0;
//          System.out.println("Enter the Product ID");
//          int prodId = scan.nextInt();
            String pattern= "[A-Z][a-z]{2,19}";
            String cName= null;
            Mobiles mobile = new Mobiles();
            
            purchaseDetails pd = new purchaseDetails();
            pd.setMobileid(mobile);
            Mobiles mobi = pd.getMobile();
            
            System.out.println("Enter the Id of the mobile purchased");
            int mobileId = scr.nextInt();
            mobi.setMobileid(mobileId);
            
            do
            {
                          
            System.out.println("Enter the Customer Name");
            cName = scr.next();
            //pattern = "[A-Z][a-z]{2,19}";

            try {
                   MobileServiceImpl.validateName(cName, pattern);
            } 
            catch (exception e1) 
            {
                   // TODO Auto-generated catch block
                   System.out.println(e1.getMessage());
            }
            }while((Pattern.matches(pattern,cName)) == false);
            
            System.out.println("Enter the Mail ID");
            String mailId = scr.next();
            
            System.out.println("Enter the Phone number");
            String pNo = scr.next();
            
//          prod.setProductId(prodId);
            pd.setCname(cName);;
            pd.setMailid(mailId);;
            pd.setPhoneno(pNo);
            pd.setPurchasedate(date);
            mobi.setMobileid(mobileId);
            
            //Calling service layer
            
            try {
                   msg = mobService.addData(pd);
            } 
            catch (exception e) 
            {
                   e.printStackTrace();
                   System.out.println(e.getMessage());
            }
            if(msg == 0)
            {
                   System.out.println("Data not Inserted....");
            }
            else
            {
                   System.out.println("Data Inserted with Product id "+msg);
            }
            break;

		case 2:
			break;
		case 3:
			break;
		case 4:
			break;
		case 5: 
			System.exit(0);
			break;
		
		
		
		
		
		
		
		
		
		}
	}while(choice!=4);
		}
		public static void printDetail(){
			System.out.println("*******************************************************************************");
			System.out.println("1) ADD product");
			System.out.println("2) show all products");
			System.out.println("3) search product");
			System.out.println("4) remove product");
			System.out.println("5) exit");
			System.out.println("******************************************************************************");
			
			
			
		}	
	}


