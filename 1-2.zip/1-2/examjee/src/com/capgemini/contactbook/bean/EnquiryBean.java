package com.capgemini.contactbook.bean;

public class EnquiryBean {
	private int enqryId;
	private String fName;
	private String IName;
	private String contactNo;
	private String pLocation;
	private String pDomain;
	
	
	
	
	public EnquiryBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EnquiryBean(int enqryId, String fName, String iName,
			String contactNo, String pLocation, String pDomain) {
		super();
		this.enqryId = enqryId;
		this.fName = fName;
		IName = iName;
		this.contactNo = contactNo;
		this.pLocation = pLocation;
		this.pDomain = pDomain;
	}
	//getter setter
	public int getEnqryId() {
		return enqryId;
	}
	public void setEnqryId(int enqryId) {
		this.enqryId = enqryId;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getIName() {
		return IName;
	}
	public void setIName(String iName) {
		IName = iName;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getpLocation() {
		return pLocation;
	}
	public void setpLocation(String pLocation) {
		this.pLocation = pLocation;
	}
	public String getpDomain() {
		return pDomain;
	}
	public void setpDomain(String pDomain) {
		this.pDomain = pDomain;
	}
	@Override
	public String toString() {
		return "EnquiryBean [enqryId=" + enqryId + ", fName=" + fName
				+ ", IName=" + IName + ", contactNo=" + contactNo
				+ ", pLocation=" + pLocation + ", pDomain=" + pDomain + "]";
	}
	
	

}
