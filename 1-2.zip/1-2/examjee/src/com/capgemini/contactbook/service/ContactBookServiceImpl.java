package com.capgemini.contactbook.service;



import java.util.regex.Pattern;



import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;

public class ContactBookServiceImpl implements ContactBookService {
	
	ContactBookDao contactbookDao = new ContactBookDaoImpl();

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		
		return contactbookDao.addEnquiry(enqry);
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryId) throws ContactBookException {
		// TODO Auto-generated method stub
		return  contactbookDao. getEnquiryDetails(EnquiryId);
	}

	@Override 
	public boolean isValidEnquiry(EnquiryBean enqry) throws ContactBookException {
		return false;
//		boolean validation=Pattern.matches(Pattern,Name);
//		if(!validation){
//			throw new ContactBookException("first letter shud b CAP,min 3,max20");
//		}
//		return validation;
	}

}
