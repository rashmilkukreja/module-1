package com.capgemini.contactbook.util;


	import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.capgemini.contactbook.exception.ContactBookException;

	
	public class Dbutil {
	
		public static Connection conn=null;
	private static final Logger mylogger = Logger.getLogger(Dbutil.class);
		 public static Connection getConnection() throws ContactBookException
		 {
			 
		 FileInputStream fileRead;
		try {
			fileRead = new FileInputStream("oracle.properties");
			Properties emps = new Properties();
			 emps.load(fileRead);
			 String driver=emps.getProperty("oracle.driver");
			 String url=emps.getProperty("oracle.url");
			 String uname=emps.getProperty("oracle.username");
			 String upass=emps.getProperty("oracle.password");
			 Class.forName(driver);
			 conn=DriverManager.getConnection(url,uname,upass);
		mylogger.info("Connection established...");
//			 throws new ContactBookException("Connection established...");
			 
		} catch (IOException | ClassNotFoundException | SQLException e) {

			e.printStackTrace();
			mylogger.info("Connection not established..."  +e);
//			throw new ContactBookException("Connection not established");
		}
		return conn;
		 
		 }
		 
		 

	}




