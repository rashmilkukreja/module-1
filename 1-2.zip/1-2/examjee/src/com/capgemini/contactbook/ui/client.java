 package com.capgemini.contactbook.ui;

import java.util.Scanner;











import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;

public class client {
	

	public static void main(String[] args) {
		 int choice =0;
		 ContactBookService bookservice=new ContactBookServiceImpl();

		do{
			printDetail();
			Scanner scr=new Scanner(System.in);
			System.out.println("enter choice");
			choice=scr.nextInt();
			
			switch(choice)
			{
			case 1://insert enquiry details
				int msg=0;
//				String patt="[A-Z][a-z]{2,19}";
//			System.out.println("enter ENQUIRY id");
//			int Id=scr.nextInt();
				System.out.println("enter FIRST name");
				String firstName=scr.next();
				System.out.println("ENTER LAST NAME");
				String lastName=scr.next();
				System.out.println("enter contact no");
				String contactno=scr.next();
				System.out.println("enter plocation");
				String plocation=scr.next();
				System.out.println("enter pdomain");
				String pdomain=scr.next();
				EnquiryBean enqry=new EnquiryBean();
//				enqry.setEnqryId(Id);
				enqry.setfName(firstName);
				enqry.setIName(lastName);
				enqry.setContactNo(contactno);
				enqry.setpLocation(plocation);
				enqry.setpDomain(pdomain);
				//call service layer
				
				
				try {
       	msg = bookservice.addEnquiry(enqry);
				} catch (ContactBookException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				if(msg==0){
					System.out.println("data not inserted" );
				}
				else{System.out.println("data inserted with id is"+msg);
				    }
				break;
				
			
			case 2: System.out.println("enter enquiry id");
			int id=scr.nextInt();
			EnquiryBean mySearch=null;
				try {
					mySearch = bookservice.getEnquiryDetails(id);
					System.out.println("id is="+mySearch.getEnqryId());
					System.out.println("fname is=" +mySearch.getfName());
					System.out.println("iname is=" +mySearch.getIName());
					System.out.println("contact no is=" +mySearch.getContactNo());
					System.out.println("plocation is"+mySearch.getpLocation());
					System.out.println("pdomain is" +mySearch.getpDomain());
					System.out.println("\n");
					
				} catch (ContactBookException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println(e.getMessage());
				}
			
			
				break;
			
			
			case 0: 
				System.exit(0);
				break;
			
			
			
			
			
			
			
			
			
			
			
			
			}
		}while(choice!=2);
			}
			public static void printDetail(){
				System.out.println("**********************GLOBAL RECRUITMENTS**********************************************");
				System.out.println("CHOOSE YOUR OPTION");
				System.out.println("1) enter enquiry details");
				System.out.println("2) view enquiry details on id");
				System.out.println("0) exit");
				System.out.println("******************************************************************************");
				System.out.println("please enter a choice: " );
				
				
				
			}

	}


