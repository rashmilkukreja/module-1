package com.capgemini.contactbook.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;










import org.apache.log4j.Logger;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.ui.client;
import com.capgemini.contactbook.util.Dbutil;




public class ContactBookDaoImpl implements ContactBookDao {

	private static final Logger myLog=Logger.getLogger(Dbutil.class);
	static Connection con=null;
	
	static PreparedStatement pstm=null;
	


	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		con=Dbutil.getConnection();
		int enquiryId=getenqryId();
		int status=0;
		String query="INSERT INTO enquiry VALUES(?,?,?,?,?,?)";
		try{
			pstm=con.prepareStatement(query);
			pstm.setInt(1,enquiryId);
			pstm.setString(2,enqry.getfName());
			pstm.setString(3,enqry.getIName());
			pstm.setString(4,enqry.getContactNo());
			pstm.setString(5,enqry.getpDomain());
			pstm.setString(6,enqry.getpLocation());
			status=pstm.executeUpdate();
//			myLog.info("Query Executed and Data Inserted");
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			try {
				throw new ContactBookException("Problem in Insert");
			} catch (ContactBookException e1) 
			{
				e1.printStackTrace();
			}
		}
		finally{
			try{
				pstm.close();
				con.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		return enquiryId;
	}
	

	

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryId) throws ContactBookException {
		EnquiryBean pSearch=null;
		try{
		con=Dbutil.getConnection();
		String queryThree="SELECT * FROM enquiry WHERE enqryId=?";
		pstm=con.prepareStatement(queryThree);
		pstm.setInt(1,EnquiryId);
		System.out.println("jg");
		pSearch=new EnquiryBean();
		ResultSet resOne=pstm.executeQuery();
		
		
		while(resOne.next()){
	
			
			pSearch.setEnqryId(resOne.getInt("enqryId"));
			pSearch.setfName(resOne.getString("firstName"));
			pSearch.setIName(resOne.getString("lastName"));
			pSearch.setContactNo(resOne.getString("contactNo"));
			pSearch.setpDomain(resOne.getString("domain"));
			pSearch.setpLocation(resOne.getString("city"));
		
		
		
		
		}}
		catch(Exception e)
		{e.printStackTrace();
		throw new ContactBookException("problem in show");
			}
		
	
		
	finally{
		try{
		pstm.close();
		con.close();}
		catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		throw new ContactBookException("problem in search");
	}
	}
	return pSearch;
	}


	@Override
	public boolean isValidEnquiry(EnquiryBean enqry) throws ContactBookException {
		// TODO Auto-generated method stub
		return false;
	}
	
	
	
	public static int getenqryId() throws ContactBookException
	{ int Id=0;
		try {
			con=Dbutil.getConnection();
			String queryFive="SELECT enquiries.nextval from DUAL";
			pstm=con.prepareStatement(queryFive);
			ResultSet resTwo=pstm.executeQuery();
			while(resTwo.next()){
				
				Id=resTwo.getInt(1);
				
			}
			
		} catch (ContactBookException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ContactBookException("problem in Getting Id");
		}
		return Id;
		
	}

}
