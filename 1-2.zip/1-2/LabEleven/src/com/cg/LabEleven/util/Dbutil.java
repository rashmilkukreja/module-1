package com.cg.LabEleven.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.cg.LabEleven.exception.UdefException;


public class Dbutil {
	static Connection conn =null;
	private static final Logger mylogger = Logger.getLogger(Dbutil.class);
	
	public static Connection getConnection() throws UdefException 
	{
		try{
		FileInputStream fileRead = new FileInputStream("oracle.properties");
		Properties pros = new Properties();
		pros.load(fileRead);
		
		String driver=pros.getProperty("oracle.driver");
		String url=pros.getProperty("oracle.url");
		String uname=pros.getProperty("oracle.username");
		String upass=pros.getProperty("oracle.password");

		//Load the driver
		Class.forName(driver);
		
		
		//Making connection
		
		 conn = DriverManager.getConnection(url,uname,upass);
		
		mylogger.info("Connection Established......!!!");
		}
		catch(IOException | ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
			mylogger.info("Connection not established"+e);
			throw new UdefException("Connection not established");
			
		}
		return conn;
	}

}
