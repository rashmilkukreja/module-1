package com.cg.LabEleven.exception;

public class UdefException extends Exception
{

	public UdefException() {
		super();
		// TODO Auto-generated constructor stub
	}


	
	

	public UdefException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
	

}
