package com.cg.LabEleven.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.LabEleven.dto.Mobile;
import com.cg.LabEleven.dto.PurchaseDetails;
import com.cg.LabEleven.exception.UdefException;
import com.cg.LabEleven.util.Dbutil;



public class LabElevenDaoImpl implements ILabElevenDao
{

	 public static  final Logger mylog = Logger.getLogger(LabElevenDaoImpl.class);
	 static Connection con = null;
	 static PreparedStatement pstm = null;

	@Override
	public List<Mobile> showall() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeMobile(int mobid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Mobile searchmobile(int minlimit, int maxlimit) {
		// TODO Auto-generated method stub
		return null;
	}

	

	@Override
	public void UpdateMobileQuantity(Mobile mob) throws UdefException {
		Connection connn=Dbutil.getConnection();
		
		String querytwo = "UPDATE MOBILES SET QUANTITY=? WHERE MOBILEID=?";
		
		  try {
			pstm = connn.prepareStatement(querytwo);
			  pstm.setInt(1,mob.getQuantity());
			  pstm.setInt(2,mob.getMobileid());
			  pstm.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		
		
	}

	@Override
	public int addPurchasedetails(PurchaseDetails pd) throws UdefException {
		Connection connn=Dbutil.getConnection();
	
		int status = 0;
		int idReturn =0;
		int purchasedid = 0;
    	//PreparedStatement pstm1 = null;
		
		try {
			
		 
		
			purchasedid = getPurchaseId();
		
		
		String queryone = "INSERT INTO purchasedetails VALUES(?,?,?,?,SYSDATE,?)";
		 status = 0;
		 idReturn =0;
		 
		java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());
		
		   pstm = connn.prepareStatement(queryone);
	    	
		pstm.setInt(1,purchasedid);
			pstm.setString(2,pd.getCname());
			pstm.setString(3,pd.getMailid());
	        pstm.setString(4,pd.getPhoneno());
	        //pstm1.setDate(5,date);
	        pstm.setInt(5,pd.getMobileid());
	        
	       
	      
	    System.out.println(date +"    "+purchasedid);
			
		//errorline
	        status = pstm.executeUpdate();
	        System.out.println(status);
	     
			
			 System.out.println(purchasedid + " " + date);
			 if(status==1)
			 {
				 idReturn = purchasedid;
				 mylog.info("Data Inserted...."+purchasedid);
			 }
		
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			try {
				pstm.close();
				connn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new UdefException("Problem in Insert.....!!!!");
			}
			
		}
		

		return idReturn;
	}
	public static int getPurchaseId() throws UdefException
	{
		int purchaseid=0;
		
		
		try {
			con=Dbutil.getConnection();
			String queryfive="SELECT PROD_ID_SEQ.NEXTVAL FROM DUAL";
			pstm=con.prepareStatement(queryfive);
			ResultSet resTwo = pstm.executeQuery();
			while(resTwo.next())
			{
				purchaseid=resTwo.getInt(1);
				
				
				
			}
			
			
			
		} catch (UdefException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UdefException("Problem in Getting id");
		}
		return purchaseid;
		
	}

}
