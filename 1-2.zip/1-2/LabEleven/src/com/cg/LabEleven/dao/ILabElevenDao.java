package com.cg.LabEleven.dao;

import java.util.ArrayList;


import java.util.List;

import com.cg.LabEleven.dto.Mobile;
import com.cg.LabEleven.dto.PurchaseDetails;
import com.cg.LabEleven.exception.UdefException;

public interface ILabElevenDao 
{
	public int addPurchasedetails(PurchaseDetails pd) throws UdefException;
	
	public void UpdateMobileQuantity(Mobile mob) throws UdefException ;
	
	public List<Mobile> showall();
	
	public void removeMobile(int mobid);
	
	public Mobile searchmobile(int minlimit, int maxlimit);
	

}
