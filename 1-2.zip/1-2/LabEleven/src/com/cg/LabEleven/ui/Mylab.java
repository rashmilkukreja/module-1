package com.cg.LabEleven.ui;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;

import com.cg.LabEleven.dto.Mobile;
import com.cg.LabEleven.dto.PurchaseDetails;
import com.cg.LabEleven.exception.UdefException;
import com.cg.LabEleven.service.ILabElevenService;
import com.cg.LabEleven.service.LabElevenServiceImpl;




public class Mylab {

	public static void main(String[] args) throws UdefException 
	{
		int choice=0;

		ILabElevenService mobileservice = new LabElevenServiceImpl();
		
		
		do
		{
			int mobid1 = 0;
			printDetails();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the Choice");
			choice=sc.nextInt();
			switch(choice)
			{
			
		case 1:
			
			String patt1="[A-Z][a-z]{2,19}";
			System.out.println("enter the customername:");
			String custName = sc.next();
			LabElevenServiceImpl.validatename(custName, patt1);
			
			String patt2="[a-z].+[a-z]@capgemini.com";
			System.out.println("enter the mailId:");
		    String mailid = sc.next();
		    LabElevenServiceImpl.validatemail(mailid, patt2);
		    
		    String patt3="[0-9]{10}";
			System.out.println("enter the phonenumber");
			String phno = sc.next();
			LabElevenServiceImpl.validatephone(phno, patt3);
			/*System.out.println("enter the purchaseddate");
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd",Locale.US);
            System.out.println("Enter date and time in the format yyyy-MM-dd");
            System.out.println("For example, it is now " + format.format(new Date()));
            Date date = null;
            while (date == null) {
            String line = sc.next();
            try {
            date = format.parse(line);
            } catch (ParseException e) {sk
            System.out.println("Sorry, that's not valid. Please try again.");
               }
               }*/
            System.out.println("enter the mobileId");
			int mobid = sc.nextInt();
			java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());
            
			PurchaseDetails pd = new PurchaseDetails();
		//	prod.setProductId(prodId);
			pd.setCname(custName);
			pd.setMailid(mailid);
			pd.setPhoneno(phno);
			pd.setPurchasedate(date);
			pd.setMobileid(mobid);
			
			// calling service layer...!!!
			int msg =0;
			
				try {
					msg = mobileservice.addPurchasedetails(pd);
					mobid1 = msg;
				} catch (UdefException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println(e.getMessage());
				}
			if(msg !=0)
			{
				System.out.println("Data Successfully addedd with purchaseid  "+msg);
				
			}
			else
			{
				System.out.println("Data not inserted.....!!!!!");
			}
			break;
			
		case 2:
			Mobile mob = new Mobile();
			PurchaseDetails pur = new PurchaseDetails();
			
			
			System.out.println("Emter the mobile quantity");
			int quantity = sc.nextInt();
			
			mob.setMobileid(mobid1);
			mob.setQuantity(quantity);
			
			
			
			break;
		case 3:
			break;
		case 4:
			break;
		case 5:
			break;
		case 6:
			break;
		
}
		
		}
	
	while(choice==6);

	}
	
	public static void printDetails()
		{
			System.out.println("*-*-*-*-*-*-*-*-*-*-*-*-*");
			System.out.println(" 1. ADD Purchase Details  ");
			System.out.println(" 2. UPDATE MOBILE QUANTITY  ");
			System.out.println(" 3.VIEW ALL  ");
			System.out.println(" 4. REMOVE MOBILE  ");
			System.out.println(" 5. SEARCH MOBILE ");
			System.out.println(" 6. EXIT ");
			System.out.println(" *-*-*-*-*-*-*-*-*-*-*-*-*  ");
		}

}
