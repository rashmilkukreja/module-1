package com.cg.LabEleven.service;

import java.util.List;

import com.cg.LabEleven.dto.Mobile;
import com.cg.LabEleven.dto.PurchaseDetails;
import com.cg.LabEleven.exception.UdefException;

public interface ILabElevenService
{
	public int addPurchasedetails(PurchaseDetails pd) throws UdefException;
	
	public void UpdateMobile(Mobile mob) ;
	
	public List<Mobile> showall();
	
	public void removeMobile(int mobid);
	
	public Mobile searchmobile(int minlimit, int maxlimit);

}
