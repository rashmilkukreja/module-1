package com.cg.LabEleven.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.LabEleven.dao.ILabElevenDao;
import com.cg.LabEleven.dao.LabElevenDaoImpl;
import com.cg.LabEleven.dto.Mobile;
import com.cg.LabEleven.dto.PurchaseDetails;
import com.cg.LabEleven.exception.UdefException;



public class LabElevenServiceImpl implements ILabElevenService
{

	ILabElevenDao purDao = new LabElevenDaoImpl();

	@Override
	public void UpdateMobile(Mobile mob) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Mobile> showall() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeMobile(int mobid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Mobile searchmobile(int minlimit, int maxlimit) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int addPurchasedetails(PurchaseDetails pd) throws UdefException {
		// TODO Auto-generated method stub
		return purDao.addPurchasedetails(pd);
	}
	public static boolean validatename(String uname, String patt1) throws UdefException
	{
		boolean validation = Pattern.matches(patt1, uname);
		
		if(!validation)
		{
			throw new UdefException("First letter should be capital  minimum 3 maximum 20");
		}
		return validation;
		
	}
	public static boolean validatemail(String mailid, String patt2) throws UdefException
	{
		boolean validation = Pattern.matches(patt2, mailid);
		if(!validation)
		{
			throw new UdefException("Entered email is not valid");
		}
		return validation;
		
	}
	public static boolean validatephone(String phoneno, String patt3) throws UdefException
	{
		boolean validation = Pattern.matches(patt3, phoneno);
		if(!validation)
		{
			throw new UdefException("Phone number shoulb be of 10 digits ");
		}
		return validation;
		
	}

}
