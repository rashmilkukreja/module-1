package com.cg.LabEleven.junitTest;

import static org.junit.Assert.*;

import org.junit.Test;

public class LabElevenDaoTest {

	@Test
	public void test() {
		
		
		
	}

}
