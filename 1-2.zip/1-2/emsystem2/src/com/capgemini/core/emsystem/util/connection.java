package com.capgemini.core.emsystem.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.capgemini.core.emsystem.beans.Employee;
import com.capgemini.core.emsystem.exception.EmployeeException;



public class connection
{
	static	Connection conn=null;
	
	public static Connection getConnection() throws EmployeeException{
	
		FileInputStream fileRead;
		try {
			fileRead = new FileInputStream("oracle.properties");
		
		Properties pros=new Properties();
		pros.load(fileRead);
		
		String driver=pros.getProperty("oracle.driver");
		String url=pros.getProperty("oracle.url");
		String uname=pros.getProperty("oracle.username");
		String upass=pros.getProperty("oracle.password");
		
		Class.forName(driver);
		
		conn=DriverManager.getConnection(url, uname, upass);
		System.out.println("connection established....");
		
		} catch (IOException | SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException("connection not establish.......");
		}
	
	return conn;
		
	
	
	
	
	
	
	
	
	
	
	
	}

	
	}
