package com.capgemini.core.emsystem.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;






import com.capgemini.core.emsystem.beans.Employee;
import com.capgemini.core.emsystem.exception.EmployeeException;
import com.capgemini.core.emsystem.util.connection;



public class employeeDAOimpl implements IEmployeeDAO 
{ private ArrayList<Employee> employeeDB = new ArrayList<>();
private int GenerateEmployeeId()
{
    return (int)(Math.random()*1000);
}


@Override
public int addEmployee(Employee employee) throws EmployeeException {
       
       employee.setId(GenerateEmployeeId());
       if( employeeDB.contains ( employee ) )
       {
              throw new EmployeeException( "Employee Already Exists With Id  " +employee.getId() );
       }
       
       employeeDB.add(employee);
 return employee.getId();
       
}


		


	@Override
	public Employee getemployee(int id) throws EmployeeException
	{
		Employee emp=new Employee();
		emp.setId(id);
		if(employeeDB.contains(emp))
		{
			int index = employeeDB.indexOf(emp);
			emp=employeeDB.get(index);
		}
		else
		{
			throw new EmployeeException("Employee not found with id"+id);
		}
		return emp;	
	}

	@Override
	public void UpdateEmployee(Employee employee) throws EmployeeException
	{
		int index =employeeDB.indexOf(employee);
		employeeDB.remove(index);
		employeeDB.add(index,employee);
	}

	@Override
	public void removeEmployee(int id) throws EmployeeException {
		Employee emp=new Employee();
		emp.setId(id);
		if(employeeDB.contains(emp))
		{
			employeeDB.remove(emp);
		}
		else
		{
			throw new EmployeeException("Employee not found with id"+id);
		}
		
	}

	@Override
	public ArrayList<Employee> getEmployee() throws EmployeeException
	{ if(employeeDB.isEmpty())
	{ throw new EmployeeException("no employee in database");}
		return employeeDB;
	}

}
