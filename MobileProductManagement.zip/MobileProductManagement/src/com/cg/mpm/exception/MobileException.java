package com.cg.mpm.exception;

public class MobileException extends Exception
{

	public MobileException()
	{
		
	}
	
	public MobileException(String msg)
	{
		super(msg);
	}

}


