package com.cg.mpm.junittest;

import static org.junit.Assert.*;

import org.junit.Test;

public class PurchaseDaoTest {

	
}
