package com.cg.mpm.junittest;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.mpm.dao.MobileDaoImpl;
import com.cg.mpm.dto.Mobiles;
import com.cg.mpm.exception.MobileException;




public class MobileDaoTest {
	
	Connection con = null;
	PreparedStatement pstm = null;
	Mobiles mob = null;
	MobileDaoImpl mobDao = null;

	@Before
	public void callBefore()
	{
		mob = new Mobiles();
		mob.setId(11111);
		mob.setName("aaaa");
		mob.setPrice(11111);
		mob.setQuantity(30);
		mobDao = new MobileDaoImpl();
	}
	
	@Test
	public void myTestCase() throws MobileException
	{
		assertEquals(1004, mobDao.addMobile(mob));
	}
	
	@After
	public void callAfter()
	{
		mob = null;
		
	}

}
