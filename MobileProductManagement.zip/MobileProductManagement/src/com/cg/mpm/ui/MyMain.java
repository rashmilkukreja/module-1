package com.cg.mpm.ui;

import com.cg.mpm.ui.MyTestOne;

public class MyMain {
	public static void main(String[] args) {
		
	

}
}