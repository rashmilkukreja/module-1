package com.cg.mpm.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mpm.dto.Mobiles;
import com.cg.mpm.dto.PurchaseDetails;
import com.cg.mpm.exception.MobileException;
import com.cg.mpm.service.IMobileService;
import com.cg.mpm.service.MobileServiceImpl;




public class MyTestOne {
	public static void mainMenu()
	{
		System.out.println("**********************CHOOSE OPTION**********************");
		System.out.println("1. Add new mobile");
		System.out.println("2. Add new purchase entry");
		System.out.println("3. View all available mobiles");
		System.out.println("4. Delete mobile");
		System.out.println("5. Search mobile based on range");
		System.out.println("6. Exit");
		System.out.println("*********************************************************");
		
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		
		
		IMobileService mobService = new MobileServiceImpl();
		
		do
		{
			switch (choice) {
			case 1://add mobile
				
				System.out.println("Enter the mobile id :");
				int id = sc.nextInt();
				System.out.println("Enter mobile name : ");
				String name = sc.next();
				System.out.println("Enter the price : ");
				double prc = sc.nextDouble();
				System.out.println("Enter the Quantity : ");
				int qntty = sc.nextInt();
				
				Mobiles mob = new Mobiles(id, name, prc, qntty);
				
				 if(qntty > 0)
				 {
					 try {
							mobService.addMobile(mob);
						} 
						 
						 catch (MobileException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				 }
				 else
				 {
					 System.out.println("The quantity should be greater than 0");
				 }
				
				
				
				break;
				
			case 2://purchase details
				System.out.println("Enter customer name : ");
				String cname = sc.next();
				System.out.println("Enter mail ID : ");
				String email = sc.next();
				System.out.println("Enter phone number");
				long phone = sc.nextLong();
				System.out.println("Enter mobile Id");
				int mobId =  sc.nextInt();
			
				PurchaseDetails pd = new PurchaseDetails();
				pd.setcName(cname);
				pd.setMailId(email);
				pd.setPhoneNo(phone);
				pd.setMobileID(mobId);
				
				try {
					mobService.addPurchase(pd);
				}
				
				catch (MobileException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
							
				break;
			
			case 3:// view all
				
				try {
					ArrayList<Mobiles> mobData =mobService.viewAllMob();
					
					for (Mobiles mobile : mobData)
				    {
						System.out.println(mobile + "\n");	
				    }
				} 
				
				catch (MobileException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
				}
				
				
				
				break;
			
			case 4://remove mobile
				System.out.println("Enter mobile id : ");
				int id1 = sc.nextInt();
				
				try {
					mobService.deleteMobiles(id1);
				}
				
				catch (MobileException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				break;
			
			case 5:// searching with price range
				
				System.out.println("Enter the lower price");
				 double min = sc.nextDouble();
				 System.out.println("Enter higher price");
				 double max = sc.nextDouble();
				 
				 ArrayList<Mobiles> mobRData = null;
				try {
					mobRData = mobService.viewMobRange(min,max);
				} 
				
				catch (MobileException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 		for (Mobiles mobile:mobRData)
			 			{
			 				System.out.println(mobile + "\n");	
			 			}
				
				break;
			
			case 6:
				System.out.println("Goodbye");
				System.exit(0);
				break;


			default:
				System.out.println("Invalid input");
				break;
			}
		}
		while(choice ==6);
		{
			
		}
}
}
