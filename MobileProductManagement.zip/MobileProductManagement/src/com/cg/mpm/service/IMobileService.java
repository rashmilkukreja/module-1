package com.cg.mpm.service;

import java.util.ArrayList;

import com.cg.mpm.dto.Mobiles;
import com.cg.mpm.dto.PurchaseDetails;
import com.cg.mpm.exception.MobileException;


public interface IMobileService {
	
	public int addMobile(Mobiles mob) throws MobileException;
	public int addPurchase(PurchaseDetails pd)  throws MobileException;
	public ArrayList<Mobiles> viewAllMob()  throws MobileException;
	public void deleteMobiles(int id)  throws MobileException;
	public ArrayList<Mobiles> viewMobRange(double low , double high)  throws MobileException;
	

}
