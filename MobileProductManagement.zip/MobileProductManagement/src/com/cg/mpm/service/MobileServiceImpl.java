package com.cg.mpm.service;

import java.util.ArrayList;

import com.cg.mpm.dao.IMobileDao;
import com.cg.mpm.dao.MobileDaoImpl;
import com.cg.mpm.dto.Mobiles;
import com.cg.mpm.dto.PurchaseDetails;
import com.cg.mpm.exception.MobileException;

public class MobileServiceImpl implements IMobileService{
	
	IMobileDao mobDao =  new MobileDaoImpl();

	@Override
	public int addMobile(Mobiles mob) throws MobileException {
		// TODO Auto-generated method stub
		return mobDao.addMobile(mob);
	}

	@Override
	public int addPurchase(PurchaseDetails pd) throws MobileException {
		// TODO Auto-generated method stub
		return mobDao.addPurchase(pd);
	}

	@Override
	public ArrayList<Mobiles> viewAllMob() throws MobileException {
		// TODO Auto-generated method stub
		return mobDao.viewAllMob();
	}

	@Override
	public void deleteMobiles(int id1) throws MobileException {
		mobDao.deleteMobiles(id1);
		
	}

	@Override
	public ArrayList<Mobiles> viewMobRange(double low, double high) throws MobileException {
		// TODO Auto-generated method stub
		return  mobDao.viewMobRange(low,high);
	}

}
