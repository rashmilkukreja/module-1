package com.cg.mpm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;

import org.apache.log4j.Logger;

import com.cg.mpm.dto.Mobiles;
import com.cg.mpm.dto.PurchaseDetails;
import com.cg.mpm.exception.MobileException;
import com.cg.mpm.util.DbUtil;



public class MobileDaoImpl implements IMobileDao
{
	private static final Logger mylog = Logger.getLogger(MobileDaoImpl.class);
	static Connection conn = null;
	static PreparedStatement pstm = null;
	int status = 0;

	@Override
	public int addMobile(Mobiles mob) throws MobileException {
		conn = DbUtil.getConnection();
		String query = "INSERT INTO mobiles VALUES(? , ? , ? , ?)";
		
		
		
		try {
			pstm = conn.prepareStatement(query);
			
			pstm.setInt(1, mob.getId());
			pstm.setString(2, mob.getName());
			pstm.setDouble(3, mob.getPrice());
			pstm.setInt(4, mob.getQuantity());
		
			status = pstm.executeUpdate();
			mylog.info("data inserted "+mob.getId());
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("Mobile cannot be saved..Domething went wrong");
		}
		finally
		{
			try {
				pstm.close();
				conn.close();
			} 
			
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return status;
	}

	@Override
	public int addPurchase(PurchaseDetails pd) throws MobileException  {
		status = 0;
		Connection conn = DbUtil.getConnection();
		PreparedStatement pstm=null;
		
		String queryone = "INSERT INTO purchasedetails VALUES(?,?,?,?,?,?)";
		try {
			pstm = conn.prepareStatement(queryone);
			

			int id = MobileDaoImpl.getPurchaseId();
			java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());	
			
			pstm.setInt ( 1,id );
			pstm.setString( 2 , pd.getcName() );
			pstm.setString( 3 , pd.getMailId() );
			pstm.setLong( 4 , pd.getPhoneNo() );
			pstm.setDate( 5 , date );
			pstm.setInt( 6 , pd.getMobileID() );
			
			status = pstm.executeUpdate();
			
			if(status > 0)
				 status = id ;
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("Purchase details invalid...");
		}
		
		
		
		return status;
	}

	@Override
	public ArrayList<Mobiles> viewAllMob() throws MobileException {
		
		Connection conn = DbUtil.getConnection();
		String querythree = "SELECT * FROM mobiles";
		ArrayList<Mobiles> mobData = new ArrayList<Mobiles>();
		
		try {
			pstm=conn.prepareStatement(querythree);
			
			Mobiles mob=null;

			ResultSet rs = pstm.executeQuery();
			while(rs.next())
				{
					mob= new Mobiles();
					mob.setId(rs.getInt(1));
					mob.setName(rs.getString(2));
					mob.setPrice(rs.getDouble(3));
					mob.setQuantity(rs.getInt(4));
			
					mobData.add(mob);
				}
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("No mobiles found...");
		}
		return  mobData;
	}

	@Override
	public void deleteMobiles(int id) throws MobileException {
		Connection conn = DbUtil.getConnection();
		String queryfour = "DELETE FROM mobiles WHERE mobileid=?";
		
		try {
			pstm=conn.prepareStatement(queryfour);
			
			pstm.setInt(1, id);
			
			int status = pstm.executeUpdate();
			if(status == 1)
				System.out.println("record deleted successfully");
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("Mobile does not exist..");
		}
		
	}

	@Override
	public ArrayList<Mobiles> viewMobRange(double low, double high) throws MobileException {
		Connection conn = DbUtil.getConnection();
		String queryfive = "SELECT * FROM mobiles WHERE price > ? AND price < ?";
		
		ArrayList<Mobiles> mobRData=null;
		
		try {
			pstm=conn.prepareStatement(queryfive);
			pstm.setDouble(1, low);
			pstm.setDouble(2, high);
			mobRData = new ArrayList();
			Mobiles mob=null;

			ResultSet rsRange = pstm.executeQuery();
			while(rsRange.next())
			{
				mob= new Mobiles();
				mob.setId(rsRange.getInt(1));
				mob.setName(rsRange.getString(2));
				mob.setPrice(rsRange.getDouble(3));
				mob.setQuantity(rsRange.getInt(4));
				mobRData.add(mob);
			}
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("No mobile found..");
		}
		return mobRData ;
	}
	
	public static int getPurchaseId() throws MobileException
	 {

		int id=0;
		
		try {
			conn=DbUtil.getConnection();
			String query = "SELECT purchaseid_sequence.nextval FROM DUAL";
			pstm =  conn.prepareStatement(query);
			ResultSet rs = pstm.executeQuery();
			
			if(rs.next())
			{
				id = rs.getInt(1);
			}
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally
		{
			try {
				pstm.close();
				conn.close();
			} 
			
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return id;
		

}
}
